# Role Hierarchy — Creator Community

Create roles **from the bottom up** in Discord (lowest rank first). Discord assigns the highest role's color.

---

## Role List (Top → Bottom)

| # | Role | Color Hex | Hoisted | Mentionable | Key Permissions |
|---|------|-----------|---------|-------------|-----------------|
| 1 | 👑 Owner | `#FFD700` | ✅ | ❌ | Administrator |
| 2 | ⚙️ Admin | `#FF4444` | ✅ | ❌ | Manage Server, Manage Roles, Ban Members |
| 3 | 🛡️ Moderator | `#00D4FF` | ✅ | ✅ | Kick Members, Timeout, Manage Messages, Mute |
| 4 | 🌟 VIP | `#FFB800` | ✅ | ✅ | Upload files, embed links, special channels |
| 5 | 🎬 Content Creator | `#B44DFF` | ✅ | ❌ | Can post in #self-promo (if gated) |
| 6 | 📺 Subscriber | `#00FF88` | ✅ | ❌ | Linked YouTube/Twitch member role |
| 7 | 🎮 Gamer | `#FF6B00` | ❌ | ❌ | Self-assign via reaction role |
| 8 | 🎨 Artist | `#FF69B4` | ❌ | ❌ | Self-assign via reaction role |
| 9 | 🎵 Music Fan | `#1DB954` | ❌ | ❌ | Self-assign via reaction role |
| 10 | 📢 Ping: Streams | `#7B68EE` | ❌ | ✅ | Notification role — pinged when going live |
| 11 | 📢 Ping: Videos | `#4169E1` | ❌ | ✅ | Notification role — pinged on video uploads |
| 12 | @everyone | — | — | — | Read Messages, Send Messages, Add Reactions |

---

## Permission Breakdown

### 👑 Owner
The server owner. Full Administrator permissions. Only one person should have this.

### ⚙️ Admin
Trusted staff who manage the server. Can:
- Manage server settings, roles, channels
- Ban/unban members
- Manage integrations and bots
- View audit log

**Do NOT give Administrator permission** — instead grant specific permissions. This prevents accidental server destruction.

### 🛡️ Moderator
Active community members who enforce rules. Can:
- Kick members (not ban — escalate to admin)
- Timeout members (up to 28 days)
- Delete messages
- Mute in voice channels
- Manage threads
- View #mod-chat and #mod-logs

### 🌟 VIP
Special members (loyal fans, supporters, collaborators). Perks:
- Custom color in member list
- Access to future VIP channels
- Higher upload limit
- Hoisted (shown separately in member list)

### 🎬 Content Creator
Verified creators in the community. Assign manually or via application.
- Shows in member list
- Can be gated to certain channels

### 📺 Subscriber
YouTube Members, Twitch Subs, or Patreon supporters. Link via:
- YouTube: Server Settings → Integrations → YouTube
- Twitch: Use a bot like StreamElements or Mee6
- Patreon: Patreon Discord integration

### 🎮🎨🎵 Interest Roles (Self-Assign)
Members pick these via reaction roles in #roles. Purely cosmetic/organizational.
Use Carl-bot reaction roles to set up (see `bots/carlbot-setup.md`).

### 📢 Ping Roles (Self-Assign)
Notification opt-in roles. Members pick these to get pinged when you:
- Go live → Ping `@Ping: Streams` in #announcements
- Upload a video → Ping `@Ping: Videos` in #announcements

---

## @everyone Permissions (Recommended Defaults)

| Permission | Value | Why |
|-----------|-------|-----|
| View Channels | ✅ | Default visibility (override per-channel) |
| Send Messages | ✅ | Let people chat |
| Embed Links | ✅ | Links show previews |
| Attach Files | ✅ | Image sharing |
| Add Reactions | ✅ | Engagement |
| Use External Emoji | ✅ | Fun |
| Read Message History | ✅ | New members can see context |
| Use Slash Commands | ✅ | Bot interactions |
| Create Public Threads | ✅ | Forum posts |
| Send Messages in Threads | ✅ | Thread replies |
| Connect (Voice) | ✅ | Voice chat |
| Speak (Voice) | ✅ | Talk in voice |
| Use Voice Activity | ✅ | No push-to-talk required |
| Mention @everyone | ❌ | **Only staff should ping everyone** |
| Manage Messages | ❌ | Staff only |
| Manage Threads | ❌ | Staff only |
| Create Invite | ✅ | Let members invite friends |

---

## How to Create Roles in Discord

1. **Server Settings** → **Roles** → **Create Role**
2. Set **name** and **color** (use hex codes from table above)
3. Toggle **Display role members separately** (Hoisted) for visible roles
4. Set permissions using the table above
5. **Important:** Create from the bottom of the list upward. The role order determines hierarchy — higher roles override lower ones.

> **Pro tip:** Drag roles to reorder them. The Owner role should always be at the top, @everyone at the bottom.
