# Custom Bot Commands — Ready to Use

Copy-paste these commands into your bot of choice (MEE6, Carl-bot, or Nightbot).

---

## Information Commands

### !socials
```
📱 **My Socials:**
🎬 YouTube → youtube.com/@yourchannel
📺 Twitch → twitch.tv/yourchannel
🐦 Twitter → twitter.com/yourhandle
📸 Instagram → instagram.com/yourhandle
🎵 TikTok → tiktok.com/@yourhandle
```

### !schedule
```
📅 **Stream Schedule (EST):**
🟢 Mon — 7:00 PM — Variety Gaming
🟢 Wed — 7:00 PM — New Releases
🟢 Fri — 8:00 PM — Community Night
🟢 Sat — 3:00 PM — Just Chatting
⚫ Tue/Thu/Sun — OFF

Check #schedule for updates!
```

### !pc / !specs
```
🖥️ **My Setup:**
CPU → AMD Ryzen 7 5800X
GPU → NVIDIA RTX 3070
RAM → 32GB DDR4 3600MHz
Monitor → 27" 1440p 165Hz
Mic → Blue Yeti / Shure SM7B
Camera → Logitech C920
Keyboard → Mechanical (your model)
Mouse → (your model)
```

### !gear
```
🎙️ **Streaming Gear:**
Software → OBS Studio
Alerts → StreamElements
Music → Pretzel Rocks (DMCA-free)
Overlays → Creator Kit 😉
Chat Bot → Nightbot + MEE6
```

---

## Engagement Commands

### !hug @user
```
💜 {user} gives {target} a big warm hug! 🤗
```

### !highfive @user
```
✋ {user} high-fives {target}! 🙌 SLAP!
```

### !lurk
```
👀 {user} is lurking! Thanks for keeping the viewer count up, you absolute legend. 💜
```

### !unlurk
```
👋 {user} has returned from the shadows! Welcome back! 🎉
```

### !gg
```
🎮 GG! Good game, well played! {user} tips their hat. 🎩
```

### !clip
```
🎬 Clip it! That was amazing! 
How to clip on Twitch: Click the 🎬 icon in the video player, or type `/clip` in chat.
```

---

## Moderation Commands (Staff Only)

### !warn
```
⚠️ **Warning:** {target}, please follow the server rules. Further violations may result in a timeout. Check #rules for our community guidelines.
```

### !timeout
```
⏰ {target} has been timed out. Reason: {reason}. Please review #rules before your timeout expires.
```

### !promo-rules
```
📋 **Self-Promo Rules (#self-promo):**
1️⃣ One post per day maximum
2️⃣ Include a description of your content
3️⃣ No "follow for follow" or "sub for sub"
4️⃣ Engage with others — don't just drop links and leave
5️⃣ Be supportive of other creators! 💜
```

---

## Utility Commands

### !report
```
🚨 To report a user or issue:
1. Right-click their message → Apps → Report
2. Or DM a Moderator with screenshots
3. Or use: `!report @user reason`

Our mod team will investigate ASAP. Thank you for keeping the community safe! 🛡️
```

### !invite
```
🔗 **Invite your friends!**
Share this link: discord.gg/YOUR-INVITE-CODE
The more the merrier! 🎉
```

### !faq
```
❓ **Frequently Asked Questions:**

**Q: How do I get roles?**
A: Go to #roles and react to the role you want!

**Q: Can I promote my channel?**
A: Yes! Post in #self-promo (one per day).

**Q: How do I become a mod?**
A: Be active, helpful, and kind. We promote from within!

**Q: When do you stream?**
A: Type `!schedule` to see the weekly schedule.
```

---

## Nightbot-Specific Commands

If using Nightbot instead of MEE6/Carl-bot:

### Add via Nightbot Dashboard:
```
!commands add !socials 📱 My Socials: YT: youtube.com/@yourchannel | Twitch: twitch.tv/yourchannel | Twitter: twitter.com/yourhandle
```

### Counter Command (Death Counter):
```
!commands add !deaths The streamer has died $(count) times this stream 💀
```

### Random Response:
```
!commands add !8ball 🎱 $(eval answers=["Yes!","No!","Maybe...","Ask again later","Definitely!","Not a chance","The stars say yes ✨","Absolutely not 🚫"]; answers[Math.floor(Math.random()*answers.length)])
```

### Uptime:
```
!commands add !uptime The stream has been live for $(twitch $(channel) "{{uptimeLength}}")
```
