# Carl-bot Setup Guide — Creator Community

[Carl-bot](https://carl.gg/) is the best Discord bot for reaction roles, advanced automod, logging, and embeds.

---

## Step 1: Invite Carl-bot

1. Go to [carl.gg](https://carl.gg/)
2. Click **Invite**
3. Select your server → Authorize
4. Open the dashboard: carl.gg/dashboard

---

## Step 2: Reaction Roles

The #1 reason to use Carl-bot. Let members self-assign roles by clicking reactions.

### Dashboard → Reaction Roles → Create

#### Reaction Role Message: Interest Roles

Post this in **#roles**:

**Embed settings:**
```
Title: 🎨 Pick Your Roles!
Color: #B44DFF
Description:
React below to assign yourself roles. Remove your reaction to remove the role.

**Interest Roles:**
🎮 — Gamer
🎨 — Artist
🎵 — Music Fan

**Notification Roles:**
📺 — Ping: Streams (get notified when I go live)
📹 — Ping: Videos (get notified when I upload)
```

**Reaction → Role mapping:**
| Emoji | Role |
|-------|------|
| 🎮 | Gamer |
| 🎨 | Artist |
| 🎵 | Music Fan |
| 📺 | Ping: Streams |
| 📹 | Ping: Videos |

**Settings:**
- Mode: **Reaction** (click to add, unclick to remove)
- Restrict to channel: **#roles**

---

## Step 3: Auto-Moderation (Supplements MEE6)

Carl-bot has more granular automod than MEE6. Use both together.

### Dashboard → Automod

#### Recommended Rules:

**Rule 1: Anti-Raid**
```
Trigger: 5+ members join within 10 seconds
Action: Enable server verification level to "High" for 10 minutes
Log to: #mod-logs
```

**Rule 2: Anti-Scam Links**
```
Trigger: Message contains known scam patterns
  - "free nitro"
  - "discord.gift" (not from Discord)
  - "steam community" (fake links)
Action: Delete message, ban user, log to #mod-logs
```

**Rule 3: Duplicate Message Spam**
```
Trigger: Same message sent 3+ times in 10 seconds
Action: Delete messages, mute for 10 minutes
Log to: #mod-logs
```

**Rule 4: New Account Filter**
```
Trigger: Account age < 7 days
Action: Log to #mod-logs (alert only — don't auto-ban, many teens make new accounts)
```

---

## Step 4: Logging

### Dashboard → Logging

Set **#mod-logs** as the log channel. Enable:

| Event | Log? | Why |
|-------|------|-----|
| Message Delete | ✅ | See what people delete |
| Message Edit | ✅ | Track edited messages |
| Member Join | ✅ | Track new members |
| Member Leave | ✅ | Track who leaves |
| Member Ban/Unban | ✅ | Moderation tracking |
| Role Changes | ✅ | Track role assignments |
| Channel Changes | ❌ | Too noisy unless debugging |
| Voice Activity | ❌ | Not useful for most servers |

---

## Step 5: Custom Embeds

Carl-bot creates the cleanest embeds. Use for announcements and pinned info.

### Stream Going Live Embed:
```
!embed #announcements
Title: 🔴 LIVE NOW
Color: #FF0040
Thumbnail: https://example.com/your-profile.png
Description:
We're live on Twitch! Come hang out!

**Playing:** [Game Name]
**Title:** [Stream Title]

🔗 **[Click to Watch](https://twitch.tv/yourchannel)**

{Ping: Streams}
Footer: See you there! 💜
```

### New Video Embed:
```
!embed #announcements
Title: 🎬 NEW VIDEO
Color: #FF0040
Description:
New video just dropped! Check it out:

**[Video Title](https://youtube.com/watch?v=EXAMPLE)**

Drop a like and comment if you enjoyed it! 🔥

{Ping: Videos}
```

---

## Step 6: Starboard

A "best of" board where the community's most-reacted messages get showcased.

### Dashboard → Starboard

- **Channel:** Create a new **#hall-of-fame** channel
- **Emoji:** ⭐
- **Threshold:** 3 reactions (adjust based on server size)
- **Self-star:** ❌ (members can't star their own messages)
- **Bot messages:** ❌ (don't starboard bot messages)
- **NSFW:** ❌ (don't allow NSFW in starboard)

---

## Carl-bot Cheat Sheet

| Command | What It Does |
|---------|--------------|
| `!role @user RoleName` | Give a role to a user |
| `!embed #channel` | Create a custom embed |
| `!tag create name content` | Create a custom tag/response |
| `!automod` | View automod settings |
| `!mute @user 10m reason` | Mute a user for 10 minutes |
| `!warn @user reason` | Warn a user |
| `!warnings @user` | View user's warnings |
| `!slowmode #channel 10` | Set 10-second slowmode |
| `!purge 50` | Delete last 50 messages |
