# MEE6 Setup Guide — Creator Community

[MEE6](https://mee6.xyz/) is the most popular Discord bot for leveling, auto-moderation, and custom commands.

---

## Step 1: Invite MEE6

1. Go to [mee6.xyz](https://mee6.xyz/)
2. Click **Add to Discord**
3. Select your server
4. Grant the requested permissions
5. You'll be redirected to the MEE6 dashboard

---

## Step 2: Enable Leveling

Leveling rewards active members and encourages engagement.

### Settings:
- **Dashboard → Leveling → Enable**
- **XP Rate:** Normal (15-25 XP per message, 1 min cooldown)
- **Level Up Message:** Send in current channel

### Level Up Message Template:
```
🎉 GG {user}! You reached **Level {level}**! Keep chatting and climbing! 🚀
```

### Role Rewards:
| Level | Role | Purpose |
|-------|------|---------|
| 5 | 🌟 Active Member | Shows they're engaged |
| 10 | 🔥 Regular | Trusted community member |
| 25 | 💎 OG | Long-time contributor |
| 50 | 👑 Legend | Ultimate dedication |

> Create these roles in Discord first, then link them in MEE6 Dashboard → Leveling → Role Rewards.

### No-XP Channels:
Disable XP gain in channels where spam could be exploited:
- #bot-commands
- #self-promo
- #memes

---

## Step 3: Auto-Moderation

### Dashboard → Moderator → Auto-Moderator

Enable these protections:

| Rule | Action | Settings |
|------|--------|----------|
| **Bad Words** | Delete + Warn | Add your custom word list. MEE6 has a default filter. |
| **Spam** | Delete + Mute 5min | Triggers on 5+ messages in 3 seconds |
| **Excessive Caps** | Delete + Warn | Triggers when 70%+ of message is caps, min 10 chars |
| **Excessive Emoji** | Delete + Warn | Triggers at 10+ emoji per message |
| **External Links** | Warn | Optional — enable if link spam is a problem |
| **Mass Mentions** | Delete + Mute 10min | Triggers at 4+ mentions |
| **Zalgo Text** | Delete | The glitchy unicode text — always delete |
| **Discord Invites** | Delete + Warn | Prevents invite link spam |

### Moderation Log Channel:
Set **#mod-logs** as the logging channel so all auto-mod actions are recorded.

---

## Step 4: Custom Commands

### Dashboard → Custom Commands

Create these useful commands:

#### !socials
```
Trigger: !socials
Response (Embed):
  Title: 📱 My Socials
  Color: #B44DFF
  Description:
    🎬 YouTube: https://youtube.com/@yourchannel
    📺 Twitch: https://twitch.tv/yourchannel
    🐦 Twitter: https://twitter.com/yourhandle
    📸 Instagram: https://instagram.com/yourhandle
    🎵 TikTok: https://tiktok.com/@yourhandle
```

#### !rules
```
Trigger: !rules
Response: Please read the rules in #rules! Breaking rules = timeout ⏰
```

#### !schedule
```
Trigger: !schedule
Response (Embed):
  Title: 📅 Stream Schedule
  Color: #00D4FF
  Description:
    🟢 Monday — 7pm EST — Variety Gaming
    🟢 Wednesday — 7pm EST — New Game Wednesdays
    🟢 Friday — 8pm EST — Community Game Night
    🟢 Saturday — 3pm EST — Chill Just Chatting
  Footer: Times in EST. Check #schedule for changes!
```

#### !collab
```
Trigger: !collab
Response: Looking for collabs? Post in #collabs with: your content type, audience size, and your idea! 🤝
```

---

## Step 5: Welcome Message

### Dashboard → Welcome → Enable

**Channel:** #lounge (or create a #welcome channel)

**Welcome Message:**
```
Hey {user}, welcome to the crew! 🎉

👋 Introduce yourself in #introductions
📜 Read the rules in #rules
🎨 Pick your roles in #roles
💬 Then come hang out in #lounge!

Enjoy your stay! 💜
```

**DM Message (Optional):**
```
Welcome to [Your Channel Name]'s Discord! 🎮

Here's how to get started:
1. Read #rules
2. Pick your roles in #roles
3. Say hi in #introductions
4. Have fun! 💜

If you have questions, ask in #lounge or DM a mod.
```
