# Server Rules — Copy-Paste Ready

Copy this entire block and paste it into your **#rules** channel. Format it as a Discord embed using Carl-bot or post as-is.

---

## 📜 Community Rules

Welcome to the community! To keep this a positive space for everyone, please follow these rules. Breaking rules may result in a warning, timeout, or ban.

---

### 1. Be Respectful
Treat everyone with kindness. No harassment, bullying, hate speech, discrimination, or personal attacks. We're all here to have fun.

### 2. No NSFW Content
This is a SFW (Safe For Work) server. No explicit images, videos, links, or discussions. This includes profile pictures and usernames.

### 3. No Spam
Don't flood channels with repeated messages, excessive caps, emoji spam, or copypasta. Bot commands go in #bot-commands.

### 4. No Self-Promo Outside #self-promo
Share your content in #self-promo only (one post per day). Don't DM members to promote. Don't drop links in other channels.

### 5. No Unsolicited DMs
Don't DM other members without their permission. Especially don't DM to promote your content, sell things, or recruit for servers.

### 6. Keep It Legal
No sharing pirated content, hacking tools, drugs, or anything illegal. No doxxing, no threats, no scams.

### 7. Follow Discord TOS
Everything that violates Discord's [Terms of Service](https://discord.com/terms) and [Community Guidelines](https://discord.com/guidelines) is also against our rules.

### 8. Listen to Moderators
If a mod asks you to stop something, stop. If you disagree with a decision, DM an admin — don't argue in public channels.

### 9. Use Channels Correctly
Post in the right channel. Memes in #memes, tech help in #tech-help, etc. Off-topic messages will be deleted.

### 10. Have Fun!
This is a community, not a courtroom. Be yourself, make friends, share your passion. We're glad you're here! 💜

---

### Consequences
- **1st offense:** Warning
- **2nd offense:** Timeout (1 hour - 24 hours)
- **3rd offense:** Extended timeout or ban
- **Severe violations:** Immediate ban (no warnings)

### Report Issues
See someone breaking rules? Right-click their message → Report, or DM a Moderator. Don't engage with trolls.

---

*Last updated: [DATE] | Rules may be updated — check back periodically.*
