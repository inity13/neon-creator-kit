# Welcome Message — Embed Template

Use Carl-bot or MEE6 to post this as an embed in your #rules or #welcome channel.

---

## Carl-bot Embed Command

Paste this in #bot-commands to send the embed to your target channel:

```
!embed #rules
```

Then edit the embed with these settings:

### Embed Settings:
```
Title: Welcome to [Your Channel Name]! 🎉
Color: #B44DFF (or your brand color)
Thumbnail: (your channel logo URL)

Description:
Hey there! Welcome to the community! We're so glad you're here. 💜

This is a chill space for creators, gamers, and anyone who wants to hang out, share content, and make friends.

**🚀 Getting Started:**

📜 **Read the Rules** → Check #rules before chatting
🎨 **Pick Your Roles** → Head to #roles and react to get your roles
👋 **Introduce Yourself** → Drop a message in #introductions
💬 **Start Chatting** → Jump into #lounge and say hi!

**📺 Stay Updated:**
React in #roles to get pinged when I go live or upload a new video!

**🔗 My Socials:**
🎬 [YouTube](https://youtube.com/@yourchannel)
📺 [Twitch](https://twitch.tv/yourchannel)
🐦 [Twitter](https://twitter.com/yourhandle)

**💡 Need Help?**
Ask in #lounge or DM a 🛡️ Moderator.

See you around! 🎮

Footer: Enjoy your stay! | [Your Channel Name]
```

---

## Plain Text Version (No Bot Needed)

If you don't want to use a bot embed, paste this directly:

```
═══════════════════════════
   Welcome to [Your Channel Name]! 🎉
═══════════════════════════

Hey there! Welcome to the community! 💜

🚀 **Getting Started:**
📜 Read #rules
🎨 Pick your roles in #roles
👋 Say hi in #introductions
💬 Chat in #lounge

📺 **Stay Updated:**
Get pinged for streams and videos — pick notification roles in #roles!

Need help? Ask a 🛡️ Moderator!

See you around! 🎮💜
```

---

## Auto-Welcome (New Member Joins)

Set this up in MEE6 or Carl-bot to automatically welcome new members.

### MEE6 Welcome Message:
```
Channel: #lounge
Message: Hey {user}, welcome to the crew! 🎉 Read #rules, pick your roles in #roles, and introduce yourself in #introductions! 💜
```

### Carl-bot Welcome Message:
```
!welcome
Channel: #lounge
Embed:
  Description: Welcome {user}! 🎉 We're glad you're here!
  
  **Quick Start:**
  📜 #rules → Read first
  🎨 #roles → Get your roles
  👋 #introductions → Say hi!
  
  Color: #B44DFF
```
