# Announcement Templates — Copy-Paste Ready

Templates for common announcements. Copy, customize, and post in #announcements.

---

## 🔴 Going Live

```
🔴 **LIVE NOW!**

**[Stream Title Here]**
🎮 Playing: [Game Name]
⏰ Started: [Time] EST

Come hang out! 👇
🔗 https://twitch.tv/yourchannel

@Ping: Streams
```

---

## 🎬 New Video

```
🎬 **NEW VIDEO DROPPED!**

**[Video Title Here]**

[One-line description of the video]

🔗 https://youtube.com/watch?v=EXAMPLE

Drop a like and comment if you enjoy it! Your support means everything! 💜

@Ping: Videos
```

---

## 📅 Schedule Update

```
📅 **This Week's Schedule**

Here's what's coming up this week:

🟢 **Monday** — 7pm EST — [Stream Activity]
🟢 **Wednesday** — 7pm EST — [Stream Activity]
🟢 **Friday** — 8pm EST — [Stream Activity]
🟢 **Saturday** — 3pm EST — [Stream Activity]
⚫ **Tue/Thu/Sun** — OFF

Times may change — check here for updates!
💜 See you there!
```

---

## 🎉 Milestone Celebration

```
🎉 **MILESTONE REACHED!**

We just hit **[NUMBER] [followers/subscribers/members]**! 🥳

This is absolutely insane. Thank you SO much to every single one of you. None of this would be possible without this amazing community.

To celebrate, [what you're doing to celebrate — special stream, giveaway, Q&A, etc.]!

💜 Love you all!
```

---

## 🏆 Giveaway

```
🏆 **GIVEAWAY TIME!**

**Prize:** [What you're giving away]

**How to Enter:**
1️⃣ React with 🎉 to this message
2️⃣ Must be a member of this server
3️⃣ [Any additional requirements]

**Winner announced:** [Date and time]

Good luck! 🍀
```

---

## 📢 Community Update

```
📢 **Community Update**

Hey everyone! Just wanted to share a few updates:

**New Stuff:**
• [Update 1]
• [Update 2]
• [Update 3]

**Coming Soon:**
• [Upcoming thing 1]
• [Upcoming thing 2]

**Reminder:**
[Any important reminder]

As always, thanks for being part of this community. You all rock! 💜
```

---

## 🤝 Collab Announcement

```
🤝 **COLLAB ALERT!**

I'm teaming up with **@[Collaborator Name]** for a special [stream/video]!

📺 **What:** [Description of collab content]
📅 **When:** [Date] at [Time] EST
🔗 **Where:** [Platform + Link]

Make sure to check out their channel too: [Link to their channel]

This is going to be epic! Don't miss it! 🔥
```

---

## ⚠️ Stream Cancelled

```
⚠️ **Stream Update**

Hey fam, unfortunately today's stream is **cancelled** due to [reason].

Next stream will be on **[next stream date and time]**.

Sorry about that! I'll make up for it with an extra long stream next time! 💜
```
