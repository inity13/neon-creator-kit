# Channel Structure — Creator Community Server

Create these categories and channels **in this exact order** (top to bottom). Discord preserves creation order.

---

## 📢 INFORMATION

> Channels your community reads but doesn't type in. Lock with `@everyone` Send Messages = ❌

### #rules
- **Type:** Text
- **Permissions:** Read-only for everyone, only admins can post
- **Description:** Read our community rules before chatting!
- **Content:** Copy from `templates/rules.md`

### #announcements
- **Type:** Announcement (enable "Follow" so members get pings)
- **Permissions:** Read-only, admins/mods can post
- **Description:** Stream schedules, video drops, and community updates
- **Slowmode:** None

### #schedule
- **Type:** Text
- **Permissions:** Read-only, admins can post
- **Description:** 📅 Weekly stream & upload schedule
- **Tip:** Pin the current week's schedule. Update every Sunday.

### #roles
- **Type:** Text
- **Permissions:** Read-only (bot handles reactions)
- **Description:** React to pick your roles! 🎨
- **Setup:** Use Carl-bot reaction roles (see `bots/carlbot-setup.md`)

---

## 💬 GENERAL

> Where the community hangs out. Standard permissions.

### #lounge
- **Type:** Text
- **Permissions:** Default (everyone can read + send)
- **Description:** Chill, chat, vibe. This is the main hangout.
- **Slowmode:** None
- **Tip:** This is your highest-traffic channel. Keep it welcoming.

### #introductions
- **Type:** Text
- **Permissions:** Default
- **Description:** New here? Tell us about yourself! What do you create? 👋
- **Slowmode:** 30 seconds (prevents spam)

### #memes
- **Type:** Text
- **Permissions:** Default
- **Description:** Memes only. Keep it SFW. 😂
- **Slowmode:** 10 seconds

### #pets
- **Type:** Text
- **Permissions:** Default
- **Description:** 🐱 Show us your pets! Cat tax is mandatory.
- **Slowmode:** None

---

## 🎮 CONTENT

> Where creators share their work and collaborate.

### #self-promo
- **Type:** Text
- **Permissions:** Default
- **Description:** Share your latest video, stream, or project! One post per day.
- **Slowmode:** 1 hour (one post per hour to prevent spam)
- **Tip:** Pin a "Self-Promo Rules" message: 1 post/day, must include description

### #clips-and-highlights
- **Type:** Text
- **Permissions:** Default
- **Description:** Share your best clips! 🎬 Short clips, funny moments, clutch plays.
- **Slowmode:** 30 seconds

### #video-ideas
- **Type:** Forum
- **Permissions:** Default
- **Description:** Brainstorm video ideas with the community! Post yours, vote on others.
- **Tags:** `gaming`, `tutorial`, `reaction`, `vlog`, `collab`, `challenge`
- **Tip:** Forum channels let each idea become its own thread — great for discussion

### #collabs
- **Type:** Text
- **Permissions:** Default
- **Description:** Looking for collab partners? Post your pitch here! 🤝
- **Slowmode:** 5 minutes

---

## 🎵 MEDIA

> Art, music, screenshots — the creative showcase.

### #art-showcase
- **Type:** Text
- **Permissions:** Default
- **Description:** Show off your art, designs, thumbnails, overlays! 🎨
- **Slowmode:** 10 seconds

### #music-share
- **Type:** Text
- **Permissions:** Default
- **Description:** Share tracks, playlists, beats. What are you listening to? 🎶
- **Slowmode:** 30 seconds

### #screenshots
- **Type:** Text
- **Permissions:** Default
- **Description:** Game screenshots, desktop setups, IRL photos 📸
- **Slowmode:** 10 seconds

### #recommendations
- **Type:** Text
- **Permissions:** Default
- **Description:** Recommend games, shows, music, tools, channels — anything!
- **Slowmode:** None

---

## 🛠️ CREATOR TOOLS

> Help each other level up. Technical channels for creator support.

### #tech-help
- **Type:** Forum
- **Permissions:** Default
- **Description:** Having tech issues? Post here and the community will help! 💻
- **Tags:** `OBS`, `audio`, `video`, `streaming`, `hardware`, `software`, `networking`
- **Tip:** Forum format keeps each issue organized as its own thread

### #stream-setup
- **Type:** Text
- **Permissions:** Default
- **Description:** Share and discuss stream setups, overlays, alerts, scenes 🎮
- **Slowmode:** None

### #editing-tips
- **Type:** Text
- **Permissions:** Default
- **Description:** Video/audio editing tips, tutorials, presets ✂️
- **Slowmode:** None

### #resources
- **Type:** Text
- **Permissions:** Read-only (mods curate, members suggest via #lounge)
- **Description:** Curated links to free tools, tutorials, assets 📚
- **Tip:** Pin a categorized resource list. Update monthly.

---

## 🔒 STAFF

> Mod-only channels. Set category permission: `@everyone` View Channel = ❌, `@Moderator` + `@Admin` View Channel = ✅

### #mod-chat
- **Type:** Text
- **Permissions:** Staff only
- **Description:** Internal mod discussion

### #mod-logs
- **Type:** Text
- **Permissions:** Staff only (bot posts here)
- **Description:** Automated moderation logs from MEE6/Carl-bot
- **Tip:** Carl-bot and MEE6 both support logging to a specific channel

### #staff-announcements
- **Type:** Text
- **Permissions:** Admin only can post, mods can read
- **Description:** Announcements for staff members

### #bot-commands
- **Type:** Text
- **Permissions:** Staff only
- **Description:** Test bot commands here without cluttering public channels

---

## 🎤 VOICE CHANNELS

Add these under the **GENERAL** category or create a new **🎤 VOICE** category:

### 🔊 Lounge
- **Type:** Voice
- **User limit:** None
- **Description:** General hangout voice channel

### 🎮 Gaming
- **Type:** Voice
- **User limit:** 10
- **Description:** For gaming sessions

### 🎵 Music
- **Type:** Voice
- **User limit:** None
- **Description:** Listen to music together (add a music bot)

### 🔇 AFK
- **Type:** Voice
- **User limit:** None
- **Description:** AFK timeout channel
- **Tip:** Set this as the AFK channel in Server Settings → Overview → AFK Channel
