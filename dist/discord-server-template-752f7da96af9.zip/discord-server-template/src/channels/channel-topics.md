# Channel Topics — Copy-Paste Ready

Set these as the channel **topic** (the text under the channel name). Keep them short and friendly.

---

## 📢 INFORMATION

| Channel | Topic |
|---------|-------|
| #rules | Read before chatting! Breaking rules = timeout or ban. |
| #announcements | Stream schedules, video drops, and community news. Turn on notifications! 🔔 |
| #schedule | This week's stream and upload schedule. Updated every Sunday. |
| #roles | React below to pick your roles! Remove your reaction to remove a role. |

## 💬 GENERAL

| Channel | Topic |
|---------|-------|
| #lounge | The main hangout. Be chill, be kind, have fun. 💜 |
| #introductions | New? Drop your intro! What do you create? Where can we find you? |
| #memes | SFW memes only. No politics. No NSFW. Just vibes. 😂 |
| #pets | Cat tax. Dog tax. All pet taxes accepted. 🐱🐶 |

## 🎮 CONTENT

| Channel | Topic |
|---------|-------|
| #self-promo | Share your latest work! One post per day, include a description. |
| #clips-and-highlights | Short clips and highlights from your streams/videos. 30sec max preferred. |
| #video-ideas | Brainstorm ideas for videos! Upvote the ones you'd watch. |
| #collabs | Looking for collab partners? Post: your content type, audience size, and idea. |

## 🎵 MEDIA

| Channel | Topic |
|---------|-------|
| #art-showcase | Your original art, designs, thumbnails, and overlays. Credit others if not yours! |
| #music-share | Share songs, playlists, and beats. Spotify, YouTube, SoundCloud all welcome. |
| #screenshots | Game screenshots, desk setups, battlestations, and IRL pics. |
| #recommendations | Recommend anything: games, shows, tools, channels, creators. |

## 🛠️ CREATOR TOOLS

| Channel | Topic |
|---------|-------|
| #tech-help | Having issues? Create a post with your problem. Include specs + screenshots! |
| #stream-setup | Share your OBS settings, overlays, alerts, and stream gear. |
| #editing-tips | Editing tricks, presets, plugins, and tutorials. |
| #resources | Curated free tools and tutorials. Suggest additions in #lounge! |
