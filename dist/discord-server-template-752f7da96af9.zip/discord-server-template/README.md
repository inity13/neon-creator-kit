# Discord Server Template — Creator Community

**A complete blueprint for building a professional Discord server for content creators.** Includes channel structure, role hierarchy, bot configurations, welcome messages, rules, and moderation setup. Ready to copy-paste.

## What's Inside

| Section | Files | Description |
|---------|-------|-------------|
| Channel Structure | `src/channels/` | Complete category + channel layout with descriptions |
| Role Hierarchy | `src/roles/` | Color-coded roles with permissions breakdown |
| Bot Configs | `src/bots/` | MEE6, Carl-bot, and Dyno ready-to-import configs |
| Templates | `src/templates/` | Rules, welcome messages, announcement formats, embed templates |

## Quick Start

1. **Create your Discord server** (or use an existing one)
2. **Set up roles** → Follow `src/roles/role-hierarchy.md` (create from bottom up!)
3. **Create channels** → Follow `src/channels/channel-structure.md`
4. **Add bots** → Import configs from `src/bots/`
5. **Post rules & welcome** → Copy from `src/templates/`

## Server Overview

This template creates a server with **6 categories, 25+ channels, and 12 roles** designed for:
- Streamers building a community
- YouTubers engaging with subscribers
- Content creators networking with other creators

### Category Layout
```
📢 INFORMATION
├── #rules
├── #announcements
├── #schedule
└── #roles (self-assign)

💬 GENERAL
├── #lounge
├── #introductions
├── #memes
└── #pets

🎮 CONTENT
├── #self-promo
├── #clips-and-highlights
├── #video-ideas
└── #collabs

🎵 MEDIA
├── #art-showcase
├── #music-share
├── #screenshots
└── #recommendations

🛠️ CREATOR TOOLS
├── #tech-help
├── #stream-setup
├── #editing-tips
└── #resources

🔒 STAFF
├── #mod-chat
├── #mod-logs
├── #staff-announcements
└── #bot-commands
```

## Customization Tips

- **Change the vibe:** Swap emoji in channel names. Use 🌸 for aesthetic, ⚡ for hype, 🌙 for chill
- **Scale up:** Add voice channels, stage channels, and forum channels as your community grows
- **Monetize:** Add subscriber-only channels for Patreon/YouTube members using role-gated permissions
- **Events:** Create temporary event channels and archive them after

## File Index

```
discord-server-template/
├── README.md
├── LICENSE
└── src/
    ├── channels/
    │   ├── channel-structure.md      # Full channel layout with descriptions
    │   └── channel-topics.md         # Suggested topic text for each channel
    ├── roles/
    │   ├── role-hierarchy.md         # Role names, colors, permissions
    │   └── role-permissions.json     # Machine-readable permissions matrix
    ├── bots/
    │   ├── mee6-setup.md             # MEE6 configuration guide
    │   ├── carlbot-setup.md          # Carl-bot reaction roles + automod
    │   └── bot-commands.md           # Custom command templates for all bots
    └── templates/
        ├── rules.md                  # Server rules (copy-paste ready)
        ├── welcome-message.md        # Welcome channel embed
        ├── announcements.md          # Announcement format templates
        └── embed-templates.json      # Discord embed JSON for bot posts
```

## License

MIT License — use freely, modify for your community, no attribution required.
