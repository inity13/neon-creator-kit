# Social Media Template Kit — Neon Edition

**14 ready-to-customize HTML templates for Instagram, TikTok, Twitter, and YouTube.** Dark neon aesthetic, mobile-ready, screenshot-to-post workflow. Open in any browser, edit the text, screenshot, and upload.

## What's Inside

| Platform | Templates | Files |
|----------|-----------|-------|
| Instagram | Quote, Carousel, Announcement, Story, Reel Cover | `src/instagram/` |
| TikTok | Video Cover, Bio Link, Challenge Banner | `src/tiktok/` |
| Twitter/X | Header, Thread Opener, Poll Card | `src/twitter/` |
| YouTube | Thumbnail, End Screen, Community Post | `src/youtube/` |
| Shared | Neon theme CSS used by all templates | `src/shared.css` |

## Quick Start

1. **Open any template** in your browser (just double-click the `.html` file)
2. **Edit the text** directly in the browser — all text fields are `contenteditable`
3. **Take a screenshot** at the right dimensions (see size guide below)
4. **Upload** to your platform of choice

> **Pro tip:** Use your browser's built-in screenshot tool for pixel-perfect captures. Firefox: `Ctrl+Shift+S`, Chrome DevTools: `Ctrl+Shift+P` → "Capture screenshot"

## Platform Size Guide

| Platform | Content Type | Dimensions | Aspect Ratio |
|----------|-------------|-----------|--------------|
| Instagram | Post / Carousel | 1080×1080 px | 1:1 |
| Instagram | Story / Reel Cover | 1080×1920 px | 9:16 |
| TikTok | Video Cover | 1080×1920 px | 9:16 |
| Twitter/X | Header | 1500×500 px | 3:1 |
| Twitter/X | Post Image | 1200×675 px | 16:9 |
| YouTube | Thumbnail | 1280×720 px | 16:9 |
| YouTube | End Screen | 1920×1080 px | 16:9 |
| YouTube | Community Post | 1200×675 px | 16:9 |

## Customization

### Changing Colors
Edit `src/shared.css` — all colors are CSS variables at the top:

```css
:root {
    --neon-pink: #FF2D9B;    /* Change to your brand color */
    --electric-blue: #00D4FF;
    --acid-green: #39FF14;
}
```

### Changing Fonts
Templates use system fonts by default (no downloads needed). To use a custom font, add a Google Fonts import to `shared.css`:

```css
@import url('https://fonts.googleapis.com/css2?family=Your+Font&display=swap');
:root {
    --font-main: 'Your Font', sans-serif;
}
```

### Adding Your Logo
Replace the placeholder SVG logo in templates with your own image:
```html
<!-- Find this in any template and replace the src -->
<img src="your-logo.png" alt="Your Channel">
```

## File Structure

```
social-media-template-kit/
├── README.md
├── LICENSE
├── src/
│   ├── shared.css              # Neon theme (all templates use this)
│   ├── instagram/
│   │   ├── quote.html          # Inspirational quote post (1080×1080)
│   │   ├── carousel.html       # Multi-slide carousel (1080×1080)
│   │   ├── announcement.html   # Big announcement post (1080×1080)
│   │   ├── story.html          # Story template (1080×1920)
│   │   └── reel-cover.html     # Reel cover image (1080×1920)
│   ├── tiktok/
│   │   ├── video-cover.html    # Video thumbnail (1080×1920)
│   │   ├── bio-link.html       # Link-in-bio page (mobile)
│   │   └── challenge-banner.html # Challenge announcement (1080×1920)
│   ├── twitter/
│   │   ├── header.html         # Profile header/banner (1500×500)
│   │   ├── thread-opener.html  # Thread first tweet image (1200×675)
│   │   └── poll-card.html      # Visual poll graphic (1200×675)
│   └── youtube/
│       ├── thumbnail.html      # Video thumbnail (1280×720)
│       ├── end-screen.html     # End screen template (1920×1080)
│       └── community-post.html # Community tab image (1200×675)
└── preview/
    └── index.html              # Visual gallery of all templates
```

## License

MIT License — use freely, modify for your brand, no attribution required.
