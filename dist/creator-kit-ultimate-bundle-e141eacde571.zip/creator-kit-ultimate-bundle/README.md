# Creator Kit Ultimate Bundle

**Every single Creator Kit product. One download. 55% off.** Get all 10 products in the Creator Kit store for $19 instead of $42 if purchased individually. Everything you need to level up your stream, YouTube channel, and social presence.

## All 10 Products

| # | Product | Individual Price | Description |
|---|---------|-----------------|-------------|
| 1 | [Content Planner System](../content-planner-system/) | $5 | Content calendar, idea tracker, and upload scheduler |
| 2 | [Discord Server Template](../discord-server-template/) | $5 | Pre-built Discord server with roles, channels, bots, and permissions |
| 3 | [Emote Creator Toolkit](../emote-creator-toolkit/) | $5 | 10 SVG emote templates + Python generator for Twitch/Discord/YouTube |
| 4 | [Neon Stream Overlay](../neon-stream-overlay/) | $5 | Complete OBS overlay package — webcam frame, alerts, scenes, panels |
| 5 | [OBS Scene Collection](../obs-scene-collection/) | $3 | Pre-built OBS scenes with sources, transitions, and layouts |
| 6 | [Social Media Template Kit](../social-media-template-kit/) | $3 | Post templates for Twitter, Instagram, Discord, and TikTok |
| 7 | [Stream Alerts Pack](../stream-alerts-pack/) | $5 | Animated alerts for follows, subs, donations, raids, and bits |
| 8 | [Stream Schedule Maker](../stream-schedule-maker/) | $3 | Schedule graphics generator, interactive builder, shareable templates |
| 9 | [Thumbnail Template Pack](../thumbnail-template-pack/) | $5 | 20 YouTube thumbnail templates in HTML/CSS — gaming, reaction, tutorial |
| 10 | [YouTube Channel Art Pack](../youtube-channel-art-pack/) | $3 | Banner templates (3 themes), profile frames, complete size reference |
| | **Individual total** | **$42** | |
| | **Bundle price** | **$19** | **Save $23 (55% off)** |

## Who This Is For

You're serious about content creation and want to look professional from day one. Instead of piecing together free assets from 10 different places, you get a complete, matching toolkit that covers:

- **Streaming:** Overlays, alerts, scenes, webcam frames, schedule graphics
- **YouTube:** Thumbnails, channel art, end screens, watermarks
- **Community:** Discord server template, social media post templates
- **Planning:** Content calendar, upload scheduler, idea tracker
- **Branding:** Custom emotes, consistent neon aesthetic across everything

## What Makes This Different

- **Everything matches.** Same dark neon aesthetic across all 10 products. Your brand looks cohesive.
- **No design software needed.** HTML/CSS templates you edit in a browser. Python scripts for batch generation.
- **Stdlib only.** Every Python script runs with zero pip installs.
- **Actually useful tools.** Interactive builders, live previews, export buttons — not just static templates.

## Quick Start

1. Browse the product folders — each has its own README.md with setup instructions
2. Start with what you need most (stream overlay? thumbnails? Discord server?)
3. Customize colors by editing CSS variables — all products use the same variable names
4. Use the Python generators for batch asset creation

## Shared CSS Variables

All products use these CSS variables. Change them once, and your brand looks consistent everywhere:

```css
:root {
  --neon-primary: #00f0ff;     /* Main accent (cyan) */
  --neon-secondary: #ff00e5;   /* Secondary accent (pink) */
  --neon-tertiary: #7b00ff;    /* Third accent (purple) */
  --bg-dark: #0a0a0f;          /* Dark background */
}
```

## Requirements

- Any modern browser (Chrome recommended for screenshots and OBS)
- Python 3.10+ for generator scripts
- OBS Studio or Streamlabs for stream overlays
- No external pip packages needed — everything is stdlib only

## License

MIT License — use freely for your stream, channel, and community. Modify, remix, share. See LICENSE file.
