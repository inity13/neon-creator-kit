# Stream Alerts Pack

**Animated stream alerts for Twitch, YouTube, and Kick** — drop-in HTML files that work as OBS browser sources. Each alert triggers a slick animation, plays for a few seconds, then disappears. No external dependencies.

## What's Included

| Alert | File | Trigger |
|-------|------|---------|
| New Follower | `src/alerts/follow.html` | Someone follows your channel |
| Subscription | `src/alerts/sub.html` | New sub / resub / gift sub |
| Donation / Tip | `src/alerts/donation.html` | StreamElements, Streamlabs, Ko-fi tips |
| Raid | `src/alerts/raid.html` | Another streamer raids your channel |
| Bits / Cheer | `src/alerts/bits.html` | Twitch bits / cheers |

**Plus:**
- `src/shared-alerts.css` — Shared animation library & theme variables
- `src/config.json` — Centralized configuration (colors, timing, sounds)
- `src/test-all.html` — Preview page that triggers all alerts in sequence

## Quick Start

1. **Preview locally:** Open `src/test-all.html` in your browser to see all alerts
2. **Add to OBS:** Add a Browser Source → point to the alert HTML file
3. **Customize:** Edit `config.json` or the CSS variables in `shared-alerts.css`
4. **Connect:** Hook up to StreamElements/Streamlabs via their widget URL system

## OBS Setup

### For each alert:
1. Open OBS Studio → Sources → **+ Add → Browser**
2. Name it (e.g., "Follow Alert")
3. Set **URL** to: `file:///path/to/stream-alerts-pack/src/alerts/follow.html`
4. Set **Width** to `800` and **Height** to `400`
5. Check **"Shutdown source when not visible"** ✅
6. Check **"Refresh browser when scene becomes active"** ✅
7. Position the browser source where you want alerts to appear

### StreamElements Integration
Replace the local file URL with your StreamElements custom widget URL and paste the HTML/CSS content into their custom code editor. The alerts use standard CSS animations — no JavaScript framework required.

### Streamlabs Integration
In Streamlabs Desktop, go to **Alert Box → Themes → Custom HTML/CSS** and paste the alert code. Each alert type maps to a Streamlabs trigger.

## Customization

### Colors (edit `shared-alerts.css`)
```css
:root {
  --alert-primary: #ff0040;    /* Main accent color */
  --alert-secondary: #00d4ff;  /* Secondary accent */
  --alert-bg: rgba(0,0,0,0.85); /* Alert background */
  --alert-text: #ffffff;        /* Text color */
  --alert-glow: #ff0040;       /* Glow/shadow color */
}
```

### Timing (edit `config.json`)
```json
{
  "animation_duration_ms": 5000,
  "entrance_style": "slide-up",
  "exit_style": "fade-out"
}
```

### Alert Text
Each HTML file has clearly marked `<!-- EDIT THIS -->` sections where you customize:
- Alert title text
- Username display format
- Message templates

## Animation Styles

Every alert includes three animation phases:
1. **Entrance** (0.5s) — Slide, bounce, or zoom in
2. **Display** (3-4s) — Holds with subtle pulse/glow animation
3. **Exit** (0.5s) — Fade out, slide away, or shrink

All animations are pure CSS `@keyframes` — no JavaScript libraries needed.

## Technical Details

- **Dimensions:** 800×400px (standard alert size, fits any stream layout)
- **Background:** Fully transparent (`body { background: transparent !important }`)
- **Fonts:** Google Fonts (Orbitron, Inter) loaded via CDN
- **Dependencies:** None — pure HTML/CSS with optional JS for WebSocket integration
- **Compatibility:** OBS Studio 28+, Streamlabs Desktop, XSplit, Lightstream

## File Structure
```
stream-alerts-pack/
├── README.md
├── LICENSE
├── SETUP.md
└── src/
    ├── shared-alerts.css
    ├── config.json
    ├── test-all.html
    └── alerts/
        ├── follow.html
        ├── sub.html
        ├── donation.html
        ├── raid.html
        └── bits.html
```

## License

MIT License — use in any stream, modify freely, no attribution required.
