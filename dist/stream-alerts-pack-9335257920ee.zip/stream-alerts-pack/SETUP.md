# Stream Alerts Pack — Setup Guide

## OBS Studio Setup (Step by Step)

### Step 1: Download & Extract
Extract the `stream-alerts-pack.zip` to a permanent location on your computer.
> **Important:** Don't put it in Downloads — if you delete it later, your alerts break!
> Recommended: `C:\StreamAssets\stream-alerts-pack\` (Windows) or `~/StreamAssets/stream-alerts-pack/` (Mac/Linux)

### Step 2: Add Follow Alert
1. Open **OBS Studio**
2. In your scene, click **+** under Sources
3. Select **Browser**
4. Name it `Follow Alert`
5. Click **OK**
6. In the properties window:
   - **Local file:** ✅ Check this box
   - **Local file path:** Browse to `src/alerts/follow.html`
   - **Width:** `800`
   - **Height:** `400`
   - **Custom CSS:** Leave empty (styles are built-in)
   - **Shutdown source when not visible:** ✅ Check this
   - **Refresh browser when scene becomes active:** ✅ Check this
7. Click **OK**
8. Position the source where you want follow alerts to appear (usually top-center)

### Step 3: Add Remaining Alerts
Repeat Step 2 for each alert type:
- `src/alerts/sub.html` → Name: `Sub Alert`
- `src/alerts/donation.html` → Name: `Donation Alert`
- `src/alerts/raid.html` → Name: `Raid Alert`
- `src/alerts/bits.html` → Name: `Bits Alert`

> **Pro tip:** Stack all alert sources in the same position. Since they're transparent when inactive, only the triggered alert will show.

### Step 4: Test Your Alerts
1. Open `src/test-all.html` in your web browser
2. Click each "Test" button to preview animations
3. Adjust timing/colors in `src/config.json` if needed

---

## StreamElements Setup

### Method A: Custom Widget (Recommended)
1. Go to [StreamElements Dashboard](https://streamelements.com/dashboard/overlays)
2. Create a **New Overlay**
3. Click **+** → **Static/Custom** → **Custom Widget**
4. In the widget editor:
   - **HTML:** Paste the contents of the alert HTML file (e.g., `follow.html`)
   - **CSS:** Paste the contents of `shared-alerts.css`
   - **JS:** Use the StreamElements event listener (see below)
5. Save and add the overlay URL to OBS as a Browser Source

### StreamElements JS Event Listener
```javascript
// Paste this in the JS field of your StreamElements custom widget
window.addEventListener('onEventReceived', function(obj) {
  const event = obj.detail.event;
  // event.type: 'follower', 'subscriber', 'tip', 'raid', 'cheer'
  // event.name: username
  // event.amount: (for tips/bits)
  // event.message: (for subs/tips)
  
  // Trigger the alert animation
  const alertEl = document.querySelector('.alert-container');
  alertEl.classList.add('active');
  
  // Update dynamic text
  document.querySelector('.username').textContent = event.name;
  
  // Auto-hide after animation
  setTimeout(() => {
    alertEl.classList.remove('active');
  }, 5000);
});
```

---

## Streamlabs Desktop Setup

1. Open **Streamlabs Desktop**
2. Go to **Alert Box** settings (Editor → Alert Box)
3. Click on the alert type (Follows, Subscriptions, etc.)
4. Switch to **Custom HTML/CSS** tab
5. Paste the HTML from the corresponding alert file
6. Paste `shared-alerts.css` into the CSS field
7. Set alert duration to match `config.json` timing (default: 5 seconds)
8. Test using the **Test** button in Streamlabs

---

## Customization Cheatsheet

### Change colors everywhere at once:
Edit `src/shared-alerts.css`, change the `:root` variables at the top.

### Change animation speed:
Edit `src/config.json`, change `animation_duration_ms`.

### Change alert text:
Open the alert HTML file, find the `<!-- EDIT THIS -->` comments.

### Change font:
In `shared-alerts.css`, change the Google Fonts import URL and the `--alert-font` variable.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Alert doesn't show in OBS | Make sure "Local file" is checked and path is correct |
| Black background instead of transparent | Add `body { background: transparent !important; }` to OBS Custom CSS |
| Alert is too small/large | Adjust Width/Height in OBS Browser Source properties |
| Alert stays on screen | Check "Shutdown source when not visible" in OBS |
| Fonts look wrong | Make sure you're connected to the internet (fonts load from Google) |
| Animation is choppy | Enable hardware acceleration in OBS: Settings → Advanced → Video |
