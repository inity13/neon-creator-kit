# Content Planner System

**Plan your content like a pro. Never run out of ideas again.** A complete content planning toolkit with weekly calendar templates, an AI-free idea generator, analytics tracking dashboard, optimal posting schedules, and 200+ niche hashtags.

## What's Inside

| File | What It Does |
|------|-------------|
| `src/weekly-planner.html` | Interactive weekly content calendar — drag, drop, plan |
| `src/content-idea-generator.py` | Python script that generates video/stream ideas on demand |
| `src/analytics-tracker.html` | Clean dashboard to track your views, subs, and growth |
| `src/posting-schedule.json` | Best times to post on every major platform |
| `src/hashtag-database.json` | 200+ hashtags sorted by niche (gaming, art, lifestyle, tech) |
| `src/style.css` | Neon cyberpunk styling shared by all HTML templates |

## Quick Start

### Weekly Planner
1. Open `src/weekly-planner.html` in any browser
2. Click on a day to add content
3. Color-code by platform (pink = YouTube, blue = Twitch, green = TikTok)
4. Export your week as JSON to save your plan

### Idea Generator
```bash
# Generate 5 random content ideas for gaming
python3 src/content-idea-generator.py --niche gaming --count 5

# Generate ideas for a specific platform
python3 src/content-idea-generator.py --niche art --platform youtube --count 10

# Get a full week of ideas (one per day)
python3 src/content-idea-generator.py --niche lifestyle --weekly

# List all available niches
python3 src/content-idea-generator.py --list-niches
```

### Analytics Tracker
1. Open `src/analytics-tracker.html` in your browser
2. Enter your weekly stats (views, subscribers, watch time, etc.)
3. See your growth trends visualized with neon charts
4. Data saves to your browser's local storage — nothing leaves your device

### Posting Schedule
Open `src/posting-schedule.json` to see the optimal posting windows for:
- YouTube (videos, shorts, community posts)
- TikTok
- Twitch (stream start times)
- Instagram (posts, stories, reels)
- Twitter/X

### Hashtag Database
Open `src/hashtag-database.json` for 200+ hashtags organized by:
- **Gaming** — general, specific games, streaming, esports
- **Art** — digital art, traditional, animation, design
- **Lifestyle** — vlogs, fashion, food, fitness
- **Tech** — coding, gadgets, tutorials, AI
- **Music** — production, covers, instruments, genres

## Customization

- **Add your own niches** to the idea generator by editing the `CONTENT_IDEAS` dictionary
- **Change colors** in `style.css` — swap the CSS variables at the top
- **Add platforms** to the posting schedule JSON — follow the existing format
- **Grow the hashtag database** — add your own hashtags to any category

## Privacy

Everything runs locally. The HTML templates use `localStorage` for saving data. The Python script needs zero internet connection. Your content plans stay on YOUR computer.

## Requirements

- Any modern browser (Chrome, Firefox, Edge, Safari)
- Python 3.10+ for the idea generator
- No pip packages needed — stdlib only

## File Structure

```
content-planner-system/
├── README.md
├── LICENSE
└── src/
    ├── weekly-planner.html        # Interactive weekly calendar
    ├── content-idea-generator.py   # Idea generator script
    ├── analytics-tracker.html      # Growth tracking dashboard
    ├── posting-schedule.json       # Optimal post times per platform
    ├── hashtag-database.json       # 200+ organized hashtags
    └── style.css                   # Shared neon theme
```

## License

MIT License — use it, remix it, plan your world takeover. No attribution needed.
