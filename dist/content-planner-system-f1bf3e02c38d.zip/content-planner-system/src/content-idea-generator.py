#!/usr/bin/env python3
"""
Content Idea Generator — Neon Bazaar Creator Kit
=================================================
Generates video, stream, and social media content ideas based on your niche.
No internet required. No API keys. Just run it and get inspired.

Usage:
    python3 content-idea-generator.py --niche gaming --count 5
    python3 content-idea-generator.py --niche art --platform youtube --count 10
    python3 content-idea-generator.py --niche lifestyle --weekly
    python3 content-idea-generator.py --list-niches
"""

from __future__ import annotations

import argparse
import json
import random
import sys
import textwrap
from datetime import datetime, timedelta
from typing import Optional

# ============================================================================
# CONTENT IDEAS DATABASE
# ============================================================================
# Each niche has categories, and each category has idea templates.
# Templates use {placeholders} that get filled with random values.
#
# WANT TO ADD YOUR OWN NICHE?
# Just follow the same format:
#   "your-niche": {
#       "category-name": [
#           "Idea template with {placeholder}",
#       ],
#       "_fills": {
#           "placeholder": ["option1", "option2", "option3"],
#       }
#   }
# ============================================================================

CONTENT_IDEAS: dict[str, dict[str, list[str] | dict[str, list[str]]]] = {
    "gaming": {
        "challenges": [
            "Beat {game} using ONLY {restriction} — can I survive?",
            "{game} but every time I {trigger}, the game gets harder",
            "Playing {game} with {weird_controller} controller challenge",
            "I let my chat pick EVERY decision in {game}",
            "Speedrun {game} in under {time_limit} — is it possible?",
            "No HUD challenge in {game} — pure skill only",
            "Playing {game} but I can only use {single_item}",
            "{game} randomizer run — everything is chaos",
        ],
        "tutorials": [
            "How to get better at {game} — {skill_count} tips that actually work",
            "Beginner's guide to {game} — everything you need to know in {year}",
            "The BEST settings for {game} on {platform_hw} (FPS boost guide)",
            "{game} tier list — what's actually meta right now",
            "How to build the PERFECT {game_build} in {game}",
            "Advanced {game_mechanic} tutorial that pros don't share",
        ],
        "entertainment": [
            "Reacting to my FIRST EVER {game} clip — how bad was I?",
            "Rating YOUR {game} builds and setups (subscriber showcase)",
            "I played {game} for 24 hours straight — here's what happened",
            "Top {list_count} most UNDERRATED {game_category} games you need to play",
            "{game} memes that keep me up at night",
            "Convincing my {person} to play {game} with me",
        ],
        "streams": [
            "Chill {game} stream — hanging with chat tonight",
            "First playthrough of {new_game} — NO SPOILERS",
            "Ranked grind in {game} — how far can we climb?",
            "Viewer games night! Come play {game} with me",
            "Building something crazy in {game} — chat decides what",
        ],
        "_fills": {
            "game": [
                "Minecraft", "Fortnite", "Valorant", "Roblox", "Apex Legends",
                "Overwatch 2", "Rocket League", "GTA V", "Stardew Valley",
                "Elden Ring", "Zelda", "Among Us", "Fall Guys", "Lethal Company",
                "Palworld", "Hogwarts Legacy", "Spider-Man 2",
            ],
            "new_game": [
                "the new indie game everyone's talking about",
                "this game that just dropped today",
                "a game my subscribers recommended",
            ],
            "restriction": [
                "a wooden sword", "the starter gear", "no weapons",
                "no jumping", "one heart", "backwards controls",
            ],
            "trigger": [
                "die", "take damage", "get a kill", "open a chest",
                "hear a sound effect", "find a rare item",
            ],
            "weird_controller": [
                "a dance mat", "a steering wheel", "bananas",
                "a guitar hero", "my phone's gyroscope", "voice commands",
            ],
            "single_item": [
                "a shield", "a fishing rod", "my fists",
                "the worst weapon", "throwables", "a pickaxe",
            ],
            "time_limit": ["10 minutes", "30 minutes", "1 hour", "5 minutes"],
            "skill_count": ["5", "7", "10", "3"],
            "platform_hw": ["PC", "PS5", "Xbox", "Switch", "low-end PC"],
            "game_build": ["base", "character", "loadout", "team comp", "deck"],
            "game_mechanic": ["aim", "movement", "building", "game sense", "positioning"],
            "game_category": ["survival", "co-op", "horror", "puzzle", "open world"],
            "list_count": ["5", "7", "10", "15"],
            "person": ["mom", "little brother", "best friend", "grandma", "teacher"],
            "year": ["2025", "2026"],
        },
    },

    "art": {
        "tutorials": [
            "How to draw {art_subject} — beginner-friendly tutorial",
            "Digital art coloring tutorial — {coloring_technique} method",
            "How I create {art_style} art from scratch (full process)",
            "Drawing {character_type} characters — tips for {skill_area}",
            "{tool_name} tutorial for beginners — everything you need to start",
            "How to shade like a pro — {shading_method} technique breakdown",
        ],
        "challenges": [
            "Drawing {art_subject} in {time_limit} — timed challenge!",
            "I let an AI generate prompts and I drew them all",
            "Redrawing my art from {years_ago} years ago — glow up?",
            "Drawing with my {non_dominant} hand for 24 hours",
            "Using ONLY {limited_tool} to create a full illustration",
            "Draw this in YOUR style challenge — {art_subject} edition",
        ],
        "process": [
            "Full illustration process — {art_subject} ({art_style} style)",
            "Sketchbook tour {year} — my best (and worst) pages",
            "My digital art setup tour — every tool I use",
            "Color palette challenge — making art with {palette_type} only",
            "How I design {character_type} characters (my full process)",
            "Speed paint — {art_subject} in {art_style} style",
        ],
        "community": [
            "Rating my subscribers' art (be brave, send yours!)",
            "Art tips I wish I knew when I started",
            "Unpopular art opinions that are actually TRUE",
            "Q&A — answering your art questions",
            "My favorite art accounts to follow in {year}",
        ],
        "_fills": {
            "art_subject": [
                "anime eyes", "a dragon", "a fantasy landscape", "a portrait",
                "cute animals", "a sunset scene", "your OC", "a mecha robot",
                "a cozy room", "mythical creatures", "food art",
            ],
            "art_style": [
                "anime", "pixel art", "watercolor", "comic book", "chibi",
                "realistic", "minimalist", "retro", "cyberpunk", "cottagecore",
            ],
            "coloring_technique": [
                "cel shading", "gradient map", "multiply layer",
                "color theory based", "complementary color",
            ],
            "character_type": [
                "OC (original character)", "fantasy", "sci-fi",
                "cute chibi", "villain", "magical girl",
            ],
            "skill_area": [
                "proportions", "expressions", "poses", "hands", "hair",
            ],
            "tool_name": [
                "Krita", "GIMP", "Medibang", "ibisPaint", "Procreate",
                "Clip Studio Paint",
            ],
            "shading_method": ["cel", "soft", "cross-hatch", "ambient occlusion"],
            "time_limit": ["10 minutes", "1 minute", "30 seconds", "5 minutes"],
            "years_ago": ["1", "2", "3", "5"],
            "non_dominant": ["left", "right", "non-dominant"],
            "limited_tool": ["one brush", "a mouse", "MS Paint", "crayons"],
            "palette_type": ["warm colors", "cool colors", "monochrome", "neon", "pastel"],
            "year": ["2025", "2026"],
        },
    },

    "lifestyle": {
        "vlogs": [
            "A day in my life as a {lifestyle_role} (realistic edition)",
            "My morning routine — {routine_style} version",
            "Room makeover on a ${budget} budget — {aesthetic} aesthetic",
            "What I eat in a day — {food_style} edition",
            "Productive day in my life — {productivity_count} things I got done",
            "Weekend vlog — {weekend_activity} with friends",
        ],
        "tips": [
            "How I stay organized as a {lifestyle_role} — {tip_count} tips",
            "My must-have apps for {app_category} in {year}",
            "How to start a {hobby} hobby — complete beginner guide",
            "Aesthetic desk setup on a budget — {aesthetic} vibes",
            "Study tips that actually work — from a {grade_level} student",
            "How to glow up in {time_period} — realistic guide",
        ],
        "hauls": [
            "${budget} {store_type} haul — is it worth it?",
            "Back to school supplies haul {year} — {aesthetic} theme",
            "Amazon finds under ${price} that changed my life",
            "Thrift flip — turning {thrift_item} into something cool",
        ],
        "entertainment": [
            "Trying {trend_name} for the first time — honest review",
            "Rating viral {category} products — are they actually good?",
            "My unpopular opinions about {opinion_topic}",
            "DIY {diy_project} — turned out {result}!",
            "Get ready with me — {event} edition",
        ],
        "_fills": {
            "lifestyle_role": [
                "a student", "a teen creator", "a content creator",
                "a high schooler", "a college freshman",
            ],
            "routine_style": ["school day", "weekend", "productive", "self-care", "lazy"],
            "budget": ["50", "20", "100", "30"],
            "aesthetic": [
                "minimalist", "cozy", "dark academia", "cottagecore",
                "cyberpunk", "Y2K", "clean girl", "indie",
            ],
            "food_style": ["healthy", "comfort food", "budget", "no-cook", "aesthetic"],
            "productivity_count": ["5", "7", "10"],
            "weekend_activity": ["shopping", "exploring", "studying", "gaming", "cooking"],
            "tip_count": ["5", "7", "10", "3"],
            "app_category": ["productivity", "school", "creativity", "fitness", "money"],
            "hobby": [
                "journaling", "photography", "coding", "cooking",
                "reading", "fitness", "drawing", "music production",
            ],
            "grade_level": ["high school", "college", "self-taught"],
            "time_period": ["30 days", "one semester", "this summer"],
            "store_type": ["Shein", "Amazon", "thrift store", "Dollar Store"],
            "price": ["10", "15", "20", "25"],
            "thrift_item": ["an old jacket", "jeans", "a basic tee", "a tote bag"],
            "trend_name": [
                "that viral TikTok recipe", "the 75 Hard challenge",
                "the no-spend month", "a silent reading marathon",
            ],
            "category": ["Amazon", "TikTok Shop", "skincare", "tech"],
            "opinion_topic": ["school", "social media", "trends", "fashion", "food"],
            "diy_project": ["phone case", "room decor", "tote bag", "jewelry", "candle"],
            "result": ["amazing", "better than expected", "kinda mid", "surprisingly good"],
            "event": ["school", "a concert", "a party", "a date", "a job interview"],
            "year": ["2025", "2026"],
        },
    },

    "tech": {
        "tutorials": [
            "How to build your first {tech_project} — complete tutorial",
            "{tool_name} crash course — learn in {time_limit}",
            "Automate {boring_task} with Python — beginner friendly",
            "How to set up {dev_tool} the RIGHT way in {year}",
            "Build a {app_type} app from scratch — no experience needed",
            "Linux for beginners — {tip_count} commands you NEED to know",
        ],
        "reviews": [
            "Is {product} worth it in {year}? Honest review",
            "Best budget {category} for students — under ${price}",
            "My {year} desk setup tour — every gadget explained",
            "I used {product} for {duration} — here's what I think",
            "Top {list_count} free tools every {role} needs",
        ],
        "challenges": [
            "Building {tech_project} in {time_limit} — can I do it?",
            "Coding with ONLY {restriction} for 24 hours",
            "I automated my entire {routine} — here's how",
            "Recreating {famous_site} from scratch in one sitting",
        ],
        "explainers": [
            "How {concept} actually works — explained simply",
            "What is {concept}? Explained for teens",
            "{concept} vs {concept_alt} — which should you learn?",
            "The truth about {myth} in tech",
        ],
        "_fills": {
            "tech_project": [
                "website", "Discord bot", "game", "portfolio site",
                "Chrome extension", "CLI tool", "calculator app",
            ],
            "tool_name": [
                "VS Code", "Git", "Python", "HTML/CSS",
                "JavaScript", "Figma", "Blender",
            ],
            "time_limit": ["30 minutes", "1 hour", "10 minutes", "a weekend"],
            "boring_task": [
                "file organizing", "homework reminders", "social media posting",
                "your desktop cleanup", "renaming files",
            ],
            "dev_tool": ["VS Code", "Git", "Node.js", "Python", "WSL"],
            "app_type": ["weather", "todo list", "quiz", "recipe", "chat"],
            "tip_count": ["5", "10", "15", "7"],
            "product": [
                "a mechanical keyboard", "a Raspberry Pi", "an iPad",
                "dual monitors", "a standing desk", "a 3D printer",
            ],
            "category": ["keyboards", "monitors", "headphones", "laptops", "tablets"],
            "price": ["50", "100", "200"],
            "duration": ["30 days", "a week", "6 months", "a year"],
            "list_count": ["5", "7", "10"],
            "role": ["student developer", "content creator", "gamer", "designer"],
            "restriction": ["Notepad", "my phone", "a 10-year-old laptop", "no mouse"],
            "routine": ["morning", "homework workflow", "content pipeline", "backup system"],
            "famous_site": ["Google homepage", "Twitter", "a popular landing page"],
            "concept": [
                "the internet", "AI", "blockchain", "algorithms",
                "APIs", "cloud computing", "encryption",
            ],
            "concept_alt": [
                "Python", "JavaScript", "React", "Vue",
                "iOS", "Android", "macOS", "Linux",
            ],
            "myth": [
                "needing a degree to code", "Macs vs PCs for coding",
                "AI replacing programmers", "you need math for coding",
            ],
            "year": ["2025", "2026"],
        },
    },

    "music": {
        "tutorials": [
            "How to make a {genre} beat from scratch — beginner tutorial",
            "{daw_name} tutorial for complete beginners",
            "Mixing vocals like a pro — {tip_count} tips",
            "How to write a {genre} song — melody and chords guide",
            "Music theory basics — everything you need in {time_limit}",
        ],
        "covers": [
            "{genre} cover of {cover_type} — my take on it",
            "Singing {cover_type} but in a completely different style",
            "I learned {instrument} in {duration} — here's the result",
            "Playing {cover_type} on {instrument} — can I pull it off?",
        ],
        "production": [
            "Making a beat using ONLY {sound_source}",
            "How I produce music in my bedroom — full setup tour",
            "Turning a {sound_source} into a {genre} beat",
            "Free vs paid {category} — can you hear the difference?",
        ],
        "community": [
            "Reacting to my subscribers' music (send yours!)",
            "My top {list_count} albums of {year}",
            "Hot takes about {genre} music that'll make you mad",
            "Q&A — music production, gear, and getting started",
        ],
        "_fills": {
            "genre": [
                "lo-fi", "trap", "pop", "rock", "EDM",
                "R&B", "indie", "hip-hop", "jazz",
            ],
            "daw_name": [
                "GarageBand", "BandLab", "FL Studio", "Ableton",
                "LMMS", "Audacity",
            ],
            "tip_count": ["5", "7", "3", "10"],
            "time_limit": ["15 minutes", "30 minutes", "1 hour"],
            "cover_type": [
                "a popular song", "a viral TikTok song",
                "a classic", "my favorite song right now",
            ],
            "instrument": [
                "guitar", "piano", "ukulele", "drums",
                "bass", "kalimba", "recorder",
            ],
            "duration": ["30 days", "a week", "1 hour", "3 months"],
            "sound_source": [
                "kitchen sounds", "my voice", "a single sample",
                "nature sounds", "a toy piano",
            ],
            "category": ["plugins", "samples", "headphones", "microphones"],
            "list_count": ["5", "10", "3"],
            "year": ["2025", "2026"],
        },
    },
}


# ============================================================================
# PLATFORM-SPECIFIC IDEA MODIFIERS
# ============================================================================
# When a platform is specified, we tweak the idea to fit the format.

PLATFORM_PREFIXES: dict[str, list[str]] = {
    "youtube": [
        "[YouTube Video]",
        "[YouTube Short]",
    ],
    "tiktok": [
        "[TikTok]",
    ],
    "twitch": [
        "[Stream Idea]",
    ],
    "instagram": [
        "[Instagram Reel]",
        "[Instagram Post]",
    ],
    "twitter": [
        "[Twitter/X Thread]",
        "[Twitter/X Post]",
    ],
}

PLATFORM_TIPS: dict[str, str] = {
    "youtube": "Tip: Use a strong hook in the first 5 seconds. Ask a question or show the end result.",
    "tiktok": "Tip: Keep it under 60 seconds. Use trending sounds. Hook viewers in the first second.",
    "twitch": "Tip: Set a clear goal for the stream. Interact with chat every few minutes.",
    "instagram": "Tip: Use 3-5 relevant hashtags. Post at peak times (see posting-schedule.json).",
    "twitter": "Tip: First tweet should be the hook. Keep threads to 5-7 tweets max.",
}


def fill_template(template: str, fills: dict[str, list[str]]) -> str:
    """Replace {placeholders} in a template with random values from fills."""
    result = template
    # Find all {placeholder} patterns and replace them
    import re
    for match in re.finditer(r'\{(\w+)\}', template):
        key = match.group(1)
        if key in fills:
            result = result.replace(match.group(0), random.choice(fills[key]), 1)
    return result


def generate_ideas(
    niche: str,
    count: int = 5,
    platform: Optional[str] = None,
    category: Optional[str] = None,
) -> list[dict[str, str]]:
    """
    Generate content ideas for a given niche.

    Args:
        niche: The content niche (gaming, art, lifestyle, tech, music)
        count: How many ideas to generate
        platform: Optional platform filter (youtube, tiktok, twitch, etc.)
        category: Optional category filter within the niche

    Returns:
        List of dicts with 'idea', 'category', 'platform', and 'tip' keys
    """
    if niche not in CONTENT_IDEAS:
        print(f"Error: Unknown niche '{niche}'.")
        print(f"Available niches: {', '.join(get_available_niches())}")
        sys.exit(1)

    niche_data = CONTENT_IDEAS[niche]
    fills = niche_data.get("_fills", {})

    # Collect all templates from the niche (or a specific category)
    templates: list[tuple[str, str]] = []  # (category_name, template)
    for cat_name, cat_templates in niche_data.items():
        if cat_name == "_fills":
            continue
        if category and cat_name != category:
            continue
        if isinstance(cat_templates, list):
            for tmpl in cat_templates:
                templates.append((cat_name, tmpl))

    if not templates:
        print(f"Error: No templates found for niche='{niche}', category='{category}'")
        sys.exit(1)

    ideas: list[dict[str, str]] = []
    used_templates: set[int] = set()

    for _ in range(count):
        # Try to pick unique templates, but allow repeats if count > templates
        available = [i for i in range(len(templates)) if i not in used_templates]
        if not available:
            used_templates.clear()
            available = list(range(len(templates)))

        idx = random.choice(available)
        used_templates.add(idx)
        cat_name, tmpl = templates[idx]
        idea_text = fill_template(tmpl, fills)

        # Add platform prefix if specified
        chosen_platform = platform or random.choice(list(PLATFORM_PREFIXES.keys()))
        prefix = random.choice(PLATFORM_PREFIXES.get(chosen_platform, [""]))
        tip = PLATFORM_TIPS.get(chosen_platform, "")

        ideas.append({
            "idea": f"{prefix} {idea_text}".strip(),
            "category": cat_name,
            "platform": chosen_platform,
            "tip": tip,
        })

    return ideas


def generate_weekly_plan(niche: str) -> dict[str, list[dict[str, str]]]:
    """
    Generate a full week of content ideas (one per day).

    Returns a dict mapping day names to idea lists.
    """
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    # Spread platforms across the week for variety
    weekly_platforms = ["youtube", "tiktok", "twitch", "instagram", "twitter", "youtube", "tiktok"]

    plan: dict[str, list[dict[str, str]]] = {}
    for day, plat in zip(days, weekly_platforms):
        ideas = generate_ideas(niche, count=1, platform=plat)
        plan[day] = ideas

    return plan


def get_available_niches() -> list[str]:
    """Return sorted list of available content niches."""
    return sorted(CONTENT_IDEAS.keys())


def print_ideas(ideas: list[dict[str, str]]) -> None:
    """Pretty-print a list of generated ideas to the terminal."""
    print()
    for i, idea in enumerate(ideas, 1):
        # Neon-style terminal output (ANSI colors)
        pink = "\033[95m"
        cyan = "\033[96m"
        green = "\033[92m"
        dim = "\033[2m"
        reset = "\033[0m"

        print(f"  {pink}{i}.{reset} {idea['idea']}")
        print(f"     {cyan}Category:{reset} {idea['category']}  "
              f"{cyan}Platform:{reset} {idea['platform']}")
        if idea.get("tip"):
            print(f"     {dim}{idea['tip']}{reset}")
        print()


def print_weekly_plan(plan: dict[str, list[dict[str, str]]]) -> None:
    """Pretty-print a weekly content plan."""
    pink = "\033[95m"
    cyan = "\033[96m"
    green = "\033[92m"
    bold = "\033[1m"
    reset = "\033[0m"

    print(f"\n  {bold}{green}=== WEEKLY CONTENT PLAN ==={reset}\n")
    for day, ideas in plan.items():
        print(f"  {cyan}{day}{reset}")
        for idea in ideas:
            print(f"    {pink}>{reset} {idea['idea']}")
            print(f"      {idea['platform']} · {idea['category']}")
        print()


def export_json(data: list[dict] | dict, filename: str) -> None:
    """Export ideas to a JSON file for use with the weekly planner."""
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"  Exported to {filename}")


# ============================================================================
# CLI
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Content Idea Generator — never run out of video/stream ideas!",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            examples:
              %(prog)s --niche gaming --count 5
              %(prog)s --niche art --platform youtube --count 10
              %(prog)s --niche lifestyle --weekly
              %(prog)s --niche tech --category tutorials --count 3
              %(prog)s --list-niches
              %(prog)s --niche gaming --count 5 --json ideas.json
        """),
    )
    parser.add_argument(
        "--niche", "-n",
        type=str,
        help="Content niche (gaming, art, lifestyle, tech, music)",
    )
    parser.add_argument(
        "--count", "-c",
        type=int,
        default=5,
        help="Number of ideas to generate (default: 5)",
    )
    parser.add_argument(
        "--platform", "-p",
        type=str,
        choices=["youtube", "tiktok", "twitch", "instagram", "twitter"],
        help="Filter ideas for a specific platform",
    )
    parser.add_argument(
        "--category",
        type=str,
        help="Filter by category within the niche (e.g., challenges, tutorials)",
    )
    parser.add_argument(
        "--weekly", "-w",
        action="store_true",
        help="Generate a full week of ideas (one per day)",
    )
    parser.add_argument(
        "--list-niches",
        action="store_true",
        help="List all available content niches",
    )
    parser.add_argument(
        "--json",
        type=str,
        metavar="FILE",
        help="Export ideas to a JSON file instead of printing",
    )
    parser.add_argument(
        "--seed",
        type=int,
        help="Random seed for reproducible results",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Optional: set random seed for reproducibility
    if args.seed is not None:
        random.seed(args.seed)

    # List niches mode
    if args.list_niches:
        niches = get_available_niches()
        print("\n  Available niches:")
        for n in niches:
            categories = [k for k in CONTENT_IDEAS[n] if k != "_fills"]
            print(f"    - {n}: {', '.join(categories)}")
        print()
        return

    # Validate niche is provided
    if not args.niche:
        parser.error("--niche is required (or use --list-niches to see options)")

    niche = args.niche.lower()

    # Weekly plan mode
    if args.weekly:
        plan = generate_weekly_plan(niche)
        if args.json:
            export_json(plan, args.json)
        else:
            print_weekly_plan(plan)
        return

    # Standard idea generation
    ideas = generate_ideas(
        niche=niche,
        count=args.count,
        platform=args.platform,
        category=args.category,
    )

    if args.json:
        export_json(ideas, args.json)
    else:
        print_ideas(ideas)


if __name__ == "__main__":
    main()
