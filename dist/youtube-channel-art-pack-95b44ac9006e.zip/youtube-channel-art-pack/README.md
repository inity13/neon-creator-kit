# YouTube Channel Art Pack

**Everything you need to make your YouTube channel look pro.** Banner templates, profile pic frames, end screen layouts, and a Python banner generator — all in the dark neon Creator Kit style. No Photoshop needed.

## What's Inside

| File | What It Does |
|------|-------------|
| `src/banner_generator.py` | Python SVG banner generator (2560x1440) with customizable text and themes |
| `src/templates/gaming_banner.json` | Gaming channel banner config |
| `src/templates/tech_banner.json` | Tech/tutorial channel banner config |
| `src/templates/vlog_banner.json` | Vlog channel banner config |
| `demo/index.html` | Interactive banner preview with live text editing |
| `preview/index.html` | Gallery showing all banner styles |
| `reference/youtube_sizes.md` | Complete YouTube asset size reference guide |

## Quick Start

### Generate a Banner
```bash
# Generate a gaming banner with default text
python3 src/banner_generator.py --theme gaming --name "YourChannel"

# Generate a tech banner with custom tagline
python3 src/banner_generator.py --theme tech --name "CodeWithMe" --tagline "Tutorials every Tuesday"

# Generate with custom neon colors
python3 src/banner_generator.py --theme gaming --name "ProGamer" --accent "#ff2d9b"

# List available themes
python3 src/banner_generator.py --list

# Generate all themes at once
python3 src/banner_generator.py --all --name "MyChannel"
```

### Use the Interactive Preview
Open `demo/index.html` in your browser. Type your channel name, pick a theme, tweak colors, and see your banner update in real time.

### Browse the Gallery
Open `preview/index.html` to see all three banner styles side by side with sample text.

## YouTube Banner Size Guide

| Zone | Dimensions | Where It Shows |
|------|-----------|----------------|
| Full banner | 2560 x 1440 | TV displays |
| Desktop safe | 2560 x 423 | Desktop browsers |
| Tablet safe | 1855 x 423 | Tablets |
| Mobile safe | 1546 x 423 | Phones (center crop) |
| Text safe area | 1235 x 338 | Guaranteed visible everywhere |

See `reference/youtube_sizes.md` for the complete guide including profile pics, thumbnails, end screens, and watermarks.

## Customization

### Change Colors
Edit CSS variables or pass `--accent` and `--secondary` flags to the generator:

```css
:root {
  --neon-primary: #00f0ff;
  --neon-secondary: #ff00e5;
  --bg-dark: #0a0a0f;
}
```

### Change Fonts
All templates use Google Fonts (Orbitron + Rajdhani). Swap the `@import` URL for different fonts.

### Add Your Logo
The SVG banners have a clearly marked `<!-- YOUR LOGO HERE -->` comment where you can paste your logo SVG path.

## File Structure

```
youtube-channel-art-pack/
├── README.md
├── LICENSE
├── src/
│   ├── banner_generator.py          # SVG banner generator
│   ├── templates/
│   │   ├── gaming_banner.json       # Gaming theme config
│   │   ├── tech_banner.json         # Tech theme config
│   │   └── vlog_banner.json         # Vlog theme config
│   ├── banners/                     # (generated banners go here)
│   ├── end-screens/                 # End screen templates
│   ├── profile-pics/                # Profile pic frames
│   └── watermarks/                  # Channel watermark templates
├── demo/
│   └── index.html                   # Interactive banner builder
├── preview/
│   └── index.html                   # Banner gallery
└── reference/
    └── youtube_sizes.md             # Complete size reference
```

## Requirements

- Any modern browser to view HTML files and the gallery
- Python 3.10+ for the generator script
- No pip packages needed — stdlib only

## License

MIT License — use these on your channel, remix them, make them yours.
