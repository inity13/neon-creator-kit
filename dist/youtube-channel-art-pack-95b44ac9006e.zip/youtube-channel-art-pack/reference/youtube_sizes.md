# YouTube Asset Size Reference Guide

Complete dimensions for every visual asset on a YouTube channel. Keep this handy when designing your channel art.

## Channel Banner (Channel Art)

| Zone | Dimensions | Notes |
|------|-----------|-------|
| **Full size** | 2560 x 1440 px | What you upload |
| **TV display** | 2560 x 1440 px | Full image shown on TVs |
| **Desktop** | 2560 x 423 px | Center strip visible on desktop |
| **Tablet** | 1855 x 423 px | Center crop on tablets |
| **Mobile** | 1546 x 423 px | Center crop on phones |
| **Text safe area** | 1235 x 338 px | Guaranteed visible on ALL devices |

### Banner Tips
- Always design at **2560 x 1440** — YouTube will crop for each device
- Put your channel name and key info in the **text safe area** (center 1235 x 338)
- Keep the outer areas simple — they'll be cropped on mobile
- File size limit: **6 MB**
- Accepted formats: JPG, PNG, BMP, non-animated GIF

## Profile Picture

| Context | Display Size | Upload Size |
|---------|-------------|-------------|
| Channel page | 98 x 98 px | 800 x 800 px (recommended) |
| Video page | 40 x 40 px | 800 x 800 px |
| Comments | 24 x 24 px | 800 x 800 px |
| Minimum | — | 98 x 98 px |

### Profile Pic Tips
- Upload at **800 x 800** or larger for crisp display
- It's displayed as a **circle** — keep important content centered
- Accepted formats: JPG, PNG, BMP, non-animated GIF
- File size limit: **No official limit** (keep under 2 MB)

## Thumbnails

| Dimension | Details |
|-----------|---------|
| **Recommended** | 1280 x 720 px |
| **Minimum width** | 640 px |
| **Aspect ratio** | 16:9 |
| **File size** | Under 2 MB |
| **Formats** | JPG, PNG, GIF, BMP |

### Thumbnail Tips
- 90% of top-performing videos use custom thumbnails
- Use bold, readable text — it needs to work at 168 x 94 px (search results)
- High contrast colors stand out in feeds
- Faces with expressions get more clicks
- Avoid clickbait — YouTube may limit reach for misleading thumbnails

## End Screens

| Element | Dimensions | Duration |
|---------|-----------|----------|
| **Video/playlist card** | Flexible (YouTube places them) | Last 5-20 seconds |
| **Subscribe button** | Flexible | Last 5-20 seconds |
| **Channel card** | Flexible | Last 5-20 seconds |
| **Link card** | Flexible | Last 5-20 seconds |
| **Safe design area** | ~1100 x 600 px (center) | — |

### End Screen Tips
- Design your video's last 20 seconds with end screen placement in mind
- Leave space in the bottom-right and bottom-left for YouTube's cards
- Max 4 elements per end screen
- Elements can appear at different times during the end screen period
- Videos must be at least 25 seconds long to have end screens

## Video Watermark (Branding)

| Setting | Details |
|---------|---------|
| **Size** | 150 x 150 px (recommended) |
| **Minimum** | 50 x 50 px |
| **Format** | PNG with transparency recommended |
| **File size** | Under 1 MB |
| **Display** | Bottom-right corner of video |

### Watermark Tips
- Use a simple, recognizable icon or logo
- Keep it semi-transparent so it doesn't distract from content
- Set timing: entire video, last 15 seconds, or custom start time
- It doubles as a subscribe button — viewers can click it

## Community Post Images

| Type | Dimensions |
|------|-----------|
| **Image post** | 1200 x 675 px (16:9 recommended) |
| **Poll image** | 1200 x 675 px |
| **Maximum** | 16 MB file size |

## Shorts Thumbnails

| Dimension | Details |
|-----------|---------|
| **Recommended** | 1080 x 1920 px (9:16) |
| **Minimum** | 640 x 1138 px |
| **Aspect ratio** | 9:16 (vertical) |

## Quick Copy-Paste Reference

```
Banner:          2560 x 1440
Banner safe:     1235 x 338 (centered)
Profile pic:     800 x 800
Thumbnail:       1280 x 720
Watermark:       150 x 150
End screen area: ~1100 x 600
Community post:  1200 x 675
Shorts thumb:    1080 x 1920
```
