#!/usr/bin/env python3
"""
YouTube Banner Generator — Neon Bazaar Creator Kit
====================================================
Generates customizable SVG YouTube channel banners (2560x1440)
with neon-themed styling. Supports gaming, tech, and vlog themes.

Usage:
    python3 banner_generator.py --theme gaming --name "YourChannel"
    python3 banner_generator.py --theme tech --name "CodeWithMe" --tagline "Tutorials every week"
    python3 banner_generator.py --all --name "MyChannel"
    python3 banner_generator.py --list
"""

from __future__ import annotations

import argparse
import json
import sys
import textwrap
from pathlib import Path
from typing import Any


# ============================================================================
# CONSTANTS
# ============================================================================

BANNER_WIDTH = 2560
BANNER_HEIGHT = 1440
SAFE_AREA_X = 662   # (2560 - 1235) / 2 ≈ 662
SAFE_AREA_Y = 551   # (1440 - 338) / 2 ≈ 551
SAFE_AREA_W = 1235
SAFE_AREA_H = 338

DEFAULT_ACCENT = "#00f0ff"
DEFAULT_SECONDARY = "#ff00e5"
DEFAULT_TERTIARY = "#7b00ff"
DEFAULT_BG = "#0a0a0f"

THEMES = ["gaming", "tech", "vlog"]


# ============================================================================
# THEME CONFIGS (loaded from JSON if available, else inline defaults)
# ============================================================================

INLINE_THEMES: dict[str, dict[str, Any]] = {
    "gaming": {
        "name": "Gaming",
        "accent": "#00f0ff",
        "secondary": "#ff00e5",
        "tertiary": "#7b00ff",
        "bg_gradient": ["#0a0a1a", "#0d0520"],
        "tagline_default": "LIVE STREAMS & GAMEPLAY",
        "decorations": "geometric",
        "icons": ["controller", "crosshair", "lightning"],
    },
    "tech": {
        "name": "Tech & Tutorials",
        "accent": "#00ff88",
        "secondary": "#00b4ff",
        "tertiary": "#8b5cf6",
        "bg_gradient": ["#0a0f0a", "#050a14"],
        "tagline_default": "TUTORIALS & TECH REVIEWS",
        "decorations": "circuit",
        "icons": ["terminal", "code", "chip"],
    },
    "vlog": {
        "name": "Vlog & Lifestyle",
        "accent": "#ff6b9d",
        "secondary": "#c084fc",
        "tertiary": "#fbbf24",
        "bg_gradient": ["#0f0a14", "#140a0f"],
        "tagline_default": "ADVENTURES & STORIES",
        "decorations": "waves",
        "icons": ["camera", "globe", "star"],
    },
}


def load_theme(theme_name: str) -> dict[str, Any]:
    """Load theme config from JSON file or fall back to inline defaults."""
    template_dir = Path(__file__).parent / "templates"
    json_path = template_dir / f"{theme_name}_banner.json"

    if json_path.exists():
        try:
            return json.loads(json_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass

    return INLINE_THEMES.get(theme_name, INLINE_THEMES["gaming"])


# ============================================================================
# SVG GENERATION
# ============================================================================

def _svg_defs(accent: str, secondary: str, tertiary: str, bg1: str, bg2: str) -> str:
    """Generate SVG defs (gradients, filters)."""
    return textwrap.dedent(f"""\
      <defs>
        <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="{bg1}"/>
          <stop offset="100%" stop-color="{bg2}"/>
        </linearGradient>
        <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stop-color="{accent}"/>
          <stop offset="50%" stop-color="{secondary}"/>
          <stop offset="100%" stop-color="{tertiary}"/>
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="4" result="blur"/>
          <feComposite in="SourceGraphic" in2="blur" operator="over"/>
        </filter>
        <filter id="softGlow">
          <feGaussianBlur stdDeviation="8" result="blur"/>
          <feComposite in="SourceGraphic" in2="blur" operator="over"/>
        </filter>
      </defs>
    """)


def _gaming_decorations(accent: str, secondary: str, tertiary: str) -> str:
    """Geometric shapes for gaming theme."""
    return textwrap.dedent(f"""\
      <!-- Geometric decorations -->
      <polygon points="200,200 280,140 280,260" fill="none" stroke="{accent}" stroke-width="2" opacity="0.15"/>
      <polygon points="2360,200 2280,140 2280,260" fill="none" stroke="{secondary}" stroke-width="2" opacity="0.15"/>
      <rect x="100" y="680" width="120" height="120" fill="none" stroke="{tertiary}" stroke-width="1.5" opacity="0.1" transform="rotate(45 160 740)"/>
      <rect x="2340" y="680" width="120" height="120" fill="none" stroke="{accent}" stroke-width="1.5" opacity="0.1" transform="rotate(45 2400 740)"/>
      <!-- Grid lines -->
      <line x1="0" y1="350" x2="2560" y2="350" stroke="{accent}" stroke-width="0.5" opacity="0.06"/>
      <line x1="0" y1="1090" x2="2560" y2="1090" stroke="{accent}" stroke-width="0.5" opacity="0.06"/>
      <line x1="400" y1="0" x2="400" y2="1440" stroke="{secondary}" stroke-width="0.5" opacity="0.04"/>
      <line x1="2160" y1="0" x2="2160" y2="1440" stroke="{secondary}" stroke-width="0.5" opacity="0.04"/>
      <!-- Corner brackets -->
      <path d="M50,50 L50,120 M50,50 L120,50" stroke="{accent}" stroke-width="2" opacity="0.2" fill="none"/>
      <path d="M2510,50 L2510,120 M2510,50 L2440,50" stroke="{accent}" stroke-width="2" opacity="0.2" fill="none"/>
      <path d="M50,1390 L50,1320 M50,1390 L120,1390" stroke="{secondary}" stroke-width="2" opacity="0.2" fill="none"/>
      <path d="M2510,1390 L2510,1320 M2510,1390 L2440,1390" stroke="{secondary}" stroke-width="2" opacity="0.2" fill="none"/>
    """)


def _tech_decorations(accent: str, secondary: str, tertiary: str) -> str:
    """Circuit board lines for tech theme."""
    return textwrap.dedent(f"""\
      <!-- Circuit board traces -->
      <path d="M0,400 L200,400 L250,350 L500,350" stroke="{accent}" stroke-width="1" opacity="0.12" fill="none"/>
      <path d="M0,600 L150,600 L200,550 L350,550 L400,600 L600,600" stroke="{secondary}" stroke-width="1" opacity="0.1" fill="none"/>
      <path d="M2560,400 L2360,400 L2310,350 L2060,350" stroke="{accent}" stroke-width="1" opacity="0.12" fill="none"/>
      <path d="M2560,1000 L2400,1000 L2350,1050 L2200,1050" stroke="{secondary}" stroke-width="1" opacity="0.1" fill="none"/>
      <!-- Circuit dots -->
      <circle cx="500" cy="350" r="4" fill="{accent}" opacity="0.2"/>
      <circle cx="600" cy="600" r="4" fill="{secondary}" opacity="0.2"/>
      <circle cx="2060" cy="350" r="4" fill="{accent}" opacity="0.2"/>
      <circle cx="2200" cy="1050" r="4" fill="{secondary}" opacity="0.2"/>
      <!-- Code brackets -->
      <text x="120" y="750" font-family="monospace" font-size="80" fill="{accent}" opacity="0.06">&lt;/&gt;</text>
      <text x="2240" y="750" font-family="monospace" font-size="80" fill="{secondary}" opacity="0.06">{"{}"}</text>
    """)


def _vlog_decorations(accent: str, secondary: str, tertiary: str) -> str:
    """Wave patterns for vlog theme."""
    return textwrap.dedent(f"""\
      <!-- Wave decorations -->
      <path d="M0,1200 Q320,1100 640,1200 Q960,1300 1280,1200 Q1600,1100 1920,1200 Q2240,1300 2560,1200" stroke="{accent}" stroke-width="1.5" opacity="0.08" fill="none"/>
      <path d="M0,1250 Q320,1150 640,1250 Q960,1350 1280,1250 Q1600,1150 1920,1250 Q2240,1350 2560,1250" stroke="{secondary}" stroke-width="1" opacity="0.06" fill="none"/>
      <path d="M0,250 Q320,350 640,250 Q960,150 1280,250 Q1600,350 1920,250 Q2240,150 2560,250" stroke="{tertiary}" stroke-width="1" opacity="0.06" fill="none"/>
      <!-- Star accents -->
      <circle cx="300" cy="300" r="2" fill="{accent}" opacity="0.3"/>
      <circle cx="2200" cy="400" r="2" fill="{secondary}" opacity="0.3"/>
      <circle cx="500" cy="1100" r="3" fill="{tertiary}" opacity="0.2"/>
      <circle cx="2100" cy="1000" r="2" fill="{accent}" opacity="0.25"/>
      <circle cx="180" cy="800" r="1.5" fill="{secondary}" opacity="0.2"/>
      <circle cx="2400" cy="700" r="1.5" fill="{accent}" opacity="0.2"/>
    """)


def generate_banner_svg(
    channel_name: str,
    theme_name: str = "gaming",
    tagline: str | None = None,
    accent_override: str | None = None,
    secondary_override: str | None = None,
) -> str:
    """Generate a complete SVG YouTube banner."""

    theme = load_theme(theme_name)

    accent = accent_override or theme.get("accent", DEFAULT_ACCENT)
    secondary = secondary_override or theme.get("secondary", DEFAULT_SECONDARY)
    tertiary = theme.get("tertiary", DEFAULT_TERTIARY)
    bg1, bg2 = theme.get("bg_gradient", [DEFAULT_BG, "#0d0520"])
    tag = tagline or theme.get("tagline_default", "CONTENT CREATOR")

    # Decorations based on theme
    decos = {
        "gaming": _gaming_decorations,
        "tech": _tech_decorations,
        "vlog": _vlog_decorations,
    }
    decoration_fn = decos.get(theme_name, _gaming_decorations)
    decorations = decoration_fn(accent, secondary, tertiary)

    svg = textwrap.dedent(f"""\
    <svg xmlns="http://www.w3.org/2000/svg" width="{BANNER_WIDTH}" height="{BANNER_HEIGHT}" viewBox="0 0 {BANNER_WIDTH} {BANNER_HEIGHT}">
      {_svg_defs(accent, secondary, tertiary, bg1, bg2)}

      <!-- Background -->
      <rect width="{BANNER_WIDTH}" height="{BANNER_HEIGHT}" fill="url(#bgGrad)"/>

      <!-- Subtle noise overlay -->
      <rect width="{BANNER_WIDTH}" height="{BANNER_HEIGHT}" fill="url(#bgGrad)" opacity="0.5"/>

      {decorations}

      <!-- Top accent line -->
      <rect x="0" y="0" width="{BANNER_WIDTH}" height="4" fill="url(#accentGrad)" opacity="0.6"/>
      <!-- Bottom accent line -->
      <rect x="0" y="{BANNER_HEIGHT - 4}" width="{BANNER_WIDTH}" height="4" fill="url(#accentGrad)" opacity="0.6"/>

      <!-- Safe area guide (invisible in final output, shown as comment) -->
      <!-- Safe area: x={SAFE_AREA_X} y={SAFE_AREA_Y} w={SAFE_AREA_W} h={SAFE_AREA_H} -->

      <!-- Channel name -->
      <text x="{BANNER_WIDTH // 2}" y="680"
            font-family="'Orbitron', 'Segoe UI', sans-serif"
            font-size="96"
            font-weight="900"
            fill="{accent}"
            text-anchor="middle"
            letter-spacing="8"
            filter="url(#glow)">
        {channel_name.upper()}
      </text>

      <!-- Tagline -->
      <text x="{BANNER_WIDTH // 2}" y="760"
            font-family="'Rajdhani', 'Segoe UI', sans-serif"
            font-size="32"
            font-weight="500"
            fill="#8899aa"
            text-anchor="middle"
            letter-spacing="6">
        {tag.upper()}
      </text>

      <!-- Divider line -->
      <line x1="{BANNER_WIDTH // 2 - 200}" y1="790"
            x2="{BANNER_WIDTH // 2 + 200}" y2="790"
            stroke="url(#accentGrad)" stroke-width="2" opacity="0.4"/>

      <!-- YOUR LOGO HERE -->
      <!-- Paste your logo SVG elements here, centered at x=1280 y=550 -->

    </svg>
    """)

    return svg


# ============================================================================
# CLI
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate neon-themed YouTube channel banners (2560x1440 SVG)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            examples:
              %(prog)s --theme gaming --name "MyChannel"
              %(prog)s --theme tech --name "CodeWithMe" --tagline "Tutorials weekly"
              %(prog)s --all --name "MyChannel"
              %(prog)s --list
        """),
    )
    parser.add_argument(
        "--theme", "-t",
        type=str,
        choices=THEMES,
        help="Banner theme (gaming, tech, vlog)",
    )
    parser.add_argument(
        "--name", "-n",
        type=str,
        default="YourChannel",
        help="Channel name displayed on the banner",
    )
    parser.add_argument(
        "--tagline",
        type=str,
        default=None,
        help="Tagline text below the channel name",
    )
    parser.add_argument(
        "--accent",
        type=str,
        default=None,
        help="Override primary accent color (hex)",
    )
    parser.add_argument(
        "--secondary",
        type=str,
        default=None,
        help="Override secondary accent color (hex)",
    )
    parser.add_argument(
        "--all", "-a",
        action="store_true",
        help="Generate all themes",
    )
    parser.add_argument(
        "--output-dir", "-o",
        type=str,
        default="./banners",
        help="Output directory (default: ./banners)",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List available themes",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Terminal colors
    cyan = "\033[96m"
    green = "\033[92m"
    pink = "\033[95m"
    dim = "\033[2m"
    reset = "\033[0m"

    if args.list:
        print(f"\n  {cyan}Available themes:{reset}")
        for t in THEMES:
            theme = load_theme(t)
            print(f"    {pink}>{reset} {t} — {theme.get('name', t)}")
        print()
        return

    if not args.theme and not args.all:
        parser.error("--theme or --all is required (use --list to see options)")

    output_dir = Path(args.output_dir)
    themes_to_gen = THEMES if args.all else [args.theme]

    for theme_name in themes_to_gen:
        svg = generate_banner_svg(
            channel_name=args.name,
            theme_name=theme_name,
            tagline=args.tagline,
            accent_override=args.accent,
            secondary_override=args.secondary,
        )
        output_path = output_dir / f"{theme_name}_banner.svg"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(svg, encoding="utf-8")
        print(f"  {green}Created:{reset} {output_path} ({BANNER_WIDTH}x{BANNER_HEIGHT})")

    total = len(themes_to_gen)
    print(f"\n  {cyan}Done!{reset} Generated {total} banner{'s' if total != 1 else ''}.")
    print(f"  {dim}Files saved to: {output_dir.resolve()}{reset}\n")


if __name__ == "__main__":
    main()
