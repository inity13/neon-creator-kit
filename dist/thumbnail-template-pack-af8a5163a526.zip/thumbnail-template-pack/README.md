# YouTube Thumbnail Template Pack

20 professional YouTube thumbnail templates in HTML/CSS. Edit text and colors directly in your browser, then screenshot to save. No design software needed.

## Templates Included

### Gaming (5 templates)
1. **Epic Win** - Large gameplay screenshot + "W" badge + player name
2. **Tier List** - S/A/B/C/D tier rows with item slots
3. **VS Battle** - Player vs Player split-screen layout
4. **Top 10** - Numbered list with large "TOP 10" text
5. **Game Review** - Score badge + game title + verdict text

### Reaction (5 templates)
6. **Shocked Face** - Large face circle + bold reaction text
7. **Drama Alert** - Breaking news style with ticker
8. **Hot Take** - Fire gradient + controversial opinion text
9. **Try Not To** - Challenge format with rules display
10. **First Time** - "FIRST TIME PLAYING" badge layout

### Tutorial (5 templates)
11. **Step by Step** - Numbered steps with arrow flow
12. **Before/After** - Split comparison layout
13. **Settings Guide** - Settings icon + game/app name
14. **Tips & Tricks** - Number badge + tip preview
15. **How To** - Clean instruction format with icon

### Other Formats (5 templates)
16. **Storytime** - Text message conversation style
17. **Challenge** - Bold challenge text with timer badge
18. **Unboxing** - Product reveal with mystery effect
19. **Collab** - Two creator names with "X" between
20. **Vlog** - Travel/lifestyle photo frame with date

## How to Use

1. Open any template HTML file in your browser (Chrome recommended)
2. Right-click any text > **Inspect** > Edit the text in DevTools
3. Or: Edit the HTML file directly in any text editor
4. Take a screenshot at 1280x720 (the template is already at this size)
5. Upload to YouTube!

### Screenshot Tips
- **Chrome:** Press F12, click the device icon, set to 1280x720, then Ctrl+Shift+P > "Capture screenshot"
- **Firefox:** Press Ctrl+Shift+S > Save full page
- **Windows:** Use Snipping Tool at exact dimensions
- **Mac:** Cmd+Shift+4 then drag to select

## Customization

Each template uses CSS variables for easy color changes:

```css
:root {
  --thumb-primary: #ff0000;     /* Main accent color */
  --thumb-secondary: #ffcc00;   /* Secondary color */
  --thumb-bg: #1a1a2e;          /* Background color */
  --thumb-text: #ffffff;         /* Text color */
}
```

## File Structure

```
src/
├── gaming/
│   ├── epic-win.html
│   ├── tier-list.html
│   ├── vs-battle.html
│   ├── top-10.html
│   └── game-review.html
├── reaction/
│   ├── shocked-face.html
│   ├── drama-alert.html
│   ├── hot-take.html
│   ├── try-not-to.html
│   └── first-time.html
├── tutorial/
│   ├── step-by-step.html
│   ├── before-after.html
│   ├── settings-guide.html
│   ├── tips-tricks.html
│   └── how-to.html
├── other/
│   ├── storytime.html
│   ├── challenge.html
│   ├── unboxing.html
│   ├── collab.html
│   └── vlog.html
└── shared.css
```

## License

MIT License - Use for any YouTube channel, modify freely.
