# Creator Kit Starter Bundle

**Three essential creator tools in one bundle — save 50%.** Get the Stream Schedule Maker, YouTube Channel Art Pack, and Social Media Template Kit together for $9 instead of $9 individually.

## What's In the Bundle

| Product | Individual Price | Description |
|---------|-----------------|-------------|
| [Stream Schedule Maker](../stream-schedule-maker/) | $3 | Schedule graphics generator, interactive builder, shareable templates |
| [YouTube Channel Art Pack](../youtube-channel-art-pack/) | $3 | Banner templates (3 themes), profile pic frames, size reference guide |
| [Social Media Template Kit](../social-media-template-kit/) | $3 | Post templates for Twitter, Instagram, Discord, and TikTok |
| **Bundle Total** | **$9** | **All 3 products** |
| **You Pay** | **$9** | **Same price, one easy download** |

## Who This Is For

You're starting a new channel or stream and need to look legit fast. This bundle gives you:

- A professional stream schedule you can share everywhere
- YouTube channel art that doesn't scream "I made this in 5 minutes"
- Social media templates for promoting your streams and videos

Everything uses the same dark neon aesthetic so your brand looks consistent across platforms.

## Quick Start

1. Pick a product folder to start with
2. Read its README.md for setup instructions
3. Customize colors, text, and layout to match your brand
4. Use the Python scripts to generate assets or edit the HTML templates directly

## What You Get

- **7 Python scripts** for generating graphics (stdlib only, no pip needed)
- **15+ HTML templates** for schedules, banners, and social posts
- **Interactive builders** with live preview in your browser
- **Complete size guides** for YouTube and social platforms
- **Dark neon theme** across everything — consistent brand vibes

## Requirements

- Any modern browser (Chrome recommended)
- Python 3.10+ for generator scripts
- No external packages needed — everything is stdlib only

## License

MIT License — use freely, modify, share, remix. See LICENSE file.
