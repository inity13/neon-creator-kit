# Scenes Reference — Source Layouts

All scenes are designed for **1920×1080** (1080p). Below is a detailed breakdown of each scene.

---

## 1. Gaming

The main gaming scene. Game fills the screen, webcam in bottom-right corner.

```
┌─────────────────────────────────────────────────┐
│ [Neon Accent Bar]                               │
│                                                 │
│                                                 │
│            [GAME CAPTURE - Full Screen]          │
│                                    ┌───────────┐│
│           [ALERTS - Top Center]    │           ││
│                                    │  WEBCAM   ││
│                         ┌────────┐ │  420x236  ││
│                         │ CHAT   │ └───────────┘│
│                         │400x600 │              │
│                         │        │              │
│                         └────────┘              │
└─────────────────────────────────────────────────┘
```

**Sources:**
| Source | Position | Size | Notes |
|--------|----------|------|-------|
| Game Capture | 0, 0 | 1920×1080 | Full screen |
| Webcam | 1480, 740 | 420×236 | Bottom-right |
| Chat Overlay | 1520, 100 | 400×600 | Right side |
| Alerts | 560, 0 | 800×400 | Top center |
| Neon Accent | 0, 0 | 1920×4 | Top bar |

---

## 2. Just Chatting

Large webcam with chat panel on the right. Good for conversation streams.

```
┌─────────────────────────────────────────────────┐
│ [Neon Accent Bar]                               │
│                                                 │
│  ┌────────────────────────┐   ┌──────────────┐  │
│  │                        │   │              │  │
│  │                        │   │              │  │
│  │     WEBCAM (Large)     │   │    CHAT      │  │
│  │     1152 x 648         │   │   400x600    │  │
│  │                        │   │              │  │
│  │                        │   │              │  │
│  └────────────────────────┘   └──────────────┘  │
│                                                 │
│  YT: @channel  |  TW: @channel  |  IG: @handle  │
└─────────────────────────────────────────────────┘
```

**Sources:**
| Source | Position | Size |
|--------|----------|------|
| Background | 0, 0 | 1920×1080 |
| Webcam | 100, 90 | 1152×648 |
| Chat | 1350, 200 | 400×600 |
| Alerts | 560, 0 | 800×400 |
| Socials Text | 100, 1000 | 1100×40 |

---

## 3. Starting Soon

Pre-stream screen. Show this while you're setting up.

```
┌─────────────────────────────────────────────────┐
│                                                 │
│                                                 │
│                                                 │
│              STARTING SOON                      │
│         ─────────────────────                   │
│    YT: @channel | TW: @channel | IG: @handle    │
│                                                 │
│                                                 │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Tip:** Add a countdown timer browser source pointing to a countdown website for extra polish.

---

## 4. BRB (Be Right Back)

Simple BRB screen for bathroom breaks, food runs, etc.

```
┌─────────────────────────────────────────────────┐
│                                                 │
│                                                 │
│                                                 │
│              BE RIGHT BACK                      │
│         ─────────────────────                   │
│                                                 │
│                                                 │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Tip:** Add a looping background video or animated browser source for visual interest.

---

## 5. Ending

End-of-stream screen with social links and raid call-to-action.

```
┌─────────────────────────────────────────────────┐
│ [Neon Accent Bar]                               │
│                                                 │
│                                                 │
│           THANKS FOR WATCHING!                  │
│                                                 │
│    YT: @channel | TW: @channel | IG: @handle    │
│                                                 │
│                                                 │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Tip:** Add a "Raid Target" text source that you update with the channel you're raiding.

---

## 6. Camera Only

Just your webcam, filling the entire screen. No overlays.

```
┌─────────────────────────────────────────────────┐
│                                                 │
│                                                 │
│                                                 │
│              WEBCAM (Full Screen)               │
│              1920 x 1080                        │
│                                                 │
│                                                 │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 7. Full Screen Game

Game capture only. No webcam, no overlays. Maximum immersion.

```
┌─────────────────────────────────────────────────┐
│                                                 │
│                                                 │
│                                                 │
│           GAME CAPTURE (Full Screen)            │
│              1920 x 1080                        │
│                                                 │
│                                                 │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## 8. IRL

For IRL/outdoor streaming. Camera fills screen with location text overlay.

```
┌─────────────────────────────────────────────────┐
│ LOCATION: Your City              [Alerts]       │
│                                                 │
│                                                 │
│              WEBCAM (Full Screen)               │
│              1920 x 1080                        │
│                                    ┌──────────┐ │
│                                    │  CHAT    │ │
│                                    │ 400x600  │ │
│                                    └──────────┘ │
│ [Neon Accent Bar - Bottom]                      │
└─────────────────────────────────────────────────┘
```

---

## 9. Tech Setup

Screen share with small webcam. Perfect for tutorials, coding, tech reviews.

```
┌─────────────────────────────────────────────────┐
│ [Neon Accent Bar]                               │
│                                                 │
│                                                 │
│         SCREEN CAPTURE (Full Screen)            │
│              1920 x 1080                        │
│                                                 │
│                                                 │
│                                    ┌──────────┐ │
│                                    │ WEBCAM   │ │
│                                    │ 380x214  │ │
└────────────────────────────────────┴──────────┘ │
```

---

## 10. Intermission

Between-segment transition screen. Use when switching activities.

```
┌─────────────────────────────────────────────────┐
│                                                 │
│                                                 │
│                                                 │
│              INTERMISSION                       │
│           We'll be right back!                  │
│         ─────────────────────                   │
│                                                 │
│                                                 │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## Shared Sources

These sources appear across multiple scenes. Edit them once and changes apply everywhere:

| Source | Used In |
|--------|---------|
| `[YOUR WEBCAM]` | Gaming, Just Chatting, Camera Only, IRL, Tech Setup |
| `[GAME CAPTURE]` | Gaming, Full Screen Game |
| `[SCREEN CAPTURE]` | Tech Setup |
| `[BROWSER: Alerts]` | Gaming, Just Chatting, IRL |
| `[BROWSER: Chat]` | Gaming, Just Chatting, IRL |
| `Text: Socials` | Just Chatting, Starting Soon, Ending |
| `BG: Dark Gradient` | Just Chatting, Starting Soon, BRB, Ending, Intermission |
| `BG: Neon Accent` | Gaming, Just Chatting, Starting Soon, BRB, Ending, IRL, Tech Setup, Intermission |
