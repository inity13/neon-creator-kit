# OBS Scene Collection — Creator Kit

**10 pre-built OBS scenes for every streaming situation.** Import one JSON file and get a complete scene setup — gaming, just chatting, BRB, starting soon, ending, and more.

## Scenes Included

| # | Scene | Use Case |
|---|-------|----------|
| 1 | Gaming | Game capture + webcam + chat + alerts |
| 2 | Just Chatting | Large webcam + chat + social panels |
| 3 | Starting Soon | Countdown + social links + hype text |
| 4 | BRB | "Be Right Back" screen |
| 5 | Ending | Thanks + social links + raid CTA |
| 6 | Camera Only | Full webcam, no overlays |
| 7 | Full Screen Game | Game capture only |
| 8 | IRL | Large camera + location text for IRL streams |
| 9 | Tech Setup | Screen share + small webcam for tutorials |
| 10 | Intermission | Between-segment transition screen |

## Quick Start

1. Open **OBS Studio**
2. Go to **Scene Collection → Import**
3. Browse to `src/scene-collection.json`
4. Select **"Creator Kit Scenes"**
5. Replace placeholder sources with your actual devices

## What You'll Need to Replace

After importing, you need to swap the placeholder sources:

| Source Name | Replace With |
|------------|--------------|
| `[YOUR WEBCAM]` | Your actual webcam (right-click → Properties → select device) |
| `[GAME CAPTURE]` | Your game capture or window capture |
| `[SCREEN CAPTURE]` | Your display/monitor capture |
| `[BROWSER: Alerts]` | Your StreamElements/Streamlabs alert URL |
| `[BROWSER: Chat]` | Your chat overlay URL |

## Scene Details

See `src/scenes-reference.md` for detailed layouts with source positions and recommended settings for each scene.

## Customization

- **Change colors:** Edit Color Source properties (right-click → Properties)
- **Move sources:** Click and drag in the preview, or use Transform → Edit Transform
- **Resize webcam:** Right-click webcam → Transform → Fit to Screen / Stretch to Screen
- **Add your overlays:** Add Browser Sources pointing to your overlay HTML files

## Requirements

- OBS Studio 28.0 or later
- 1920×1080 base resolution (standard 1080p)
- Webcam, microphone (for applicable scenes)

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Sources show as red | Right-click → Properties → reselect your device |
| Wrong resolution | Settings → Video → Base Resolution: 1920x1080 |
| Scenes look different | Make sure Canvas Resolution matches 1920x1080 |
| Can't find the import | Scene Collection menu → Import (not File → Import) |

## License

MIT License — use freely, modify for your streams, no attribution required.
