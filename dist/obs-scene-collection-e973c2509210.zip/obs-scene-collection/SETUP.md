# OBS Scene Collection — Setup Guide

## Step 1: Download & Extract

Extract `obs-scene-collection.zip` to a permanent folder:
- **Windows:** `C:\StreamAssets\obs-scene-collection\`
- **Mac:** `~/StreamAssets/obs-scene-collection/`
- **Linux:** `~/StreamAssets/obs-scene-collection/`

## Step 2: Import into OBS Studio

1. Open **OBS Studio**
2. Go to the menu bar: **Scene Collection → Import**
3. Click **Browse** (or the file icon)
4. Navigate to `src/scene-collection.json`
5. Click **Open**
6. The collection "Creator Kit Scenes" will appear in the import list
7. Click **Import**
8. Switch to it: **Scene Collection → Creator Kit Scenes**

## Step 3: Replace Placeholder Sources

The imported scenes use placeholder sources. You need to replace them with your real devices.

### Replace Webcam
1. In any scene with `[YOUR WEBCAM]`, right-click the source
2. Select **Properties**
3. In the **Device** dropdown, select your webcam
4. Click **OK**
5. Resize/reposition as needed

### Replace Game Capture
1. Right-click `[GAME CAPTURE]`
2. Select **Properties**
3. **Mode:** Capture specific window (recommended) or Capture any fullscreen application
4. **Window:** Select your game
5. Click **OK**

### Replace Screen Capture
1. Right-click `[SCREEN CAPTURE]`
2. Select **Properties**
3. Select your monitor
4. Click **OK**

### Set Up Browser Sources
1. Right-click any `[BROWSER: ...]` source
2. Select **Properties**
3. Replace the placeholder URL with your real URL:
   - **Alerts:** Your StreamElements/Streamlabs alert widget URL
   - **Chat:** Your chat overlay URL (StreamElements, KapChat, etc.)
   - **Overlay:** Your overlay HTML file path (from neon-stream-overlay product if purchased)
4. Set dimensions as recommended in the source name
5. Click **OK**

## Step 4: Configure Audio

1. Go to **Settings → Audio**
2. Set your **Desktop Audio** device
3. Set your **Mic/Auxiliary Audio** device
4. The scenes already include audio mixer entries — they'll connect to your devices

## Step 5: Set Up Scene Transitions

The collection includes basic transitions, but you can customize:
1. In the **Scene Transitions** dock, select your preferred transition
2. **Cut** — instant switch (best for most scenes)
3. **Fade** — smooth fade (great for Starting Soon → Gaming transitions)
4. Duration: 300ms recommended for Fade

## Step 6: Test Everything

1. Switch between scenes using the scene list
2. Verify your webcam appears correctly in each scene
3. Test game capture with a game running
4. Set up hotkeys: **Settings → Hotkeys** → assign keys to switch scenes

## Recommended Hotkeys

| Scene | Suggested Hotkey |
|-------|-----------------|
| Gaming | F1 |
| Just Chatting | F2 |
| Starting Soon | F3 |
| BRB | F4 |
| Ending | F5 |
| Camera Only | F6 |
| Full Screen Game | F7 |

## Troubleshooting

### Sources show red/missing
Right-click → Properties → reselect the device or file path. Sources turn red when OBS can't find the device.

### Resolution looks wrong
Go to **Settings → Video**:
- **Base (Canvas) Resolution:** 1920x1080
- **Output (Scaled) Resolution:** 1920x1080 (or 1280x720 for lower bitrate)

### Scenes didn't import
Make sure you're using OBS Studio 28.0+ and the JSON file isn't corrupted. Try re-extracting the zip.
