# OBS Setup Guide - Neon Stream Overlay

Step-by-step instructions to set up the Neon Stream Overlay in OBS Studio and Streamlabs.

## Prerequisites

- OBS Studio 28+ or Streamlabs Desktop
- The overlay files unzipped to a folder on your computer

## Step 1: Set Up Your Scenes

Create these scenes in OBS (right-click in the Scenes panel > Add):

1. **Gaming** - Your main gameplay scene
2. **Starting Soon** - Pre-stream countdown
3. **BRB** - When you step away
4. **Ending** - End of stream

## Step 2: Add the Gaming Scene

### 2a. Add Game Capture
1. In the **Gaming** scene, click `+` under Sources
2. Select **Game Capture** (or Window/Display Capture)
3. Configure to capture your game

### 2b. Add Webcam
1. Click `+` > **Video Capture Device**
2. Select your webcam
3. Resize to roughly 420x236 in the bottom-left corner

### 2c. Add Webcam Frame
1. Click `+` > **Browser**
2. Name it "Webcam Frame"
3. Check **Local file** and browse to `webcam-frame.html`
4. Set Width: `420`, Height: `236`
5. Position it EXACTLY over your webcam source
6. Make sure it's ABOVE the webcam in the source list

### 2d. Add the Full Gaming Scene Layout
1. Click `+` > **Browser**
2. Name it "Gaming Layout"
3. Local file: `scenes/gaming.html`
4. Width: `1920`, Height: `1080`
5. This adds the top bar, webcam frame, side panels, and ticker
6. Move it above your game capture but below your webcam frame

### 2e. Add Panels (Optional - if not using the full scene)
Add each panel as a separate Browser Source:
- `panels/game-info.html` - 300x80
- `panels/recent-events.html` - 300x200
- `panels/goals.html` - 300x60

## Step 3: Add Alert Sources

Alerts should be added to EVERY scene where you want them to appear. The easiest way:

1. Click `+` > **Browser**
2. Name it "Follow Alert"
3. Local file: `alerts/follow.html`
4. Width: `500`, Height: `200`
5. Position it center-top of your screen
6. Repeat for `sub.html`, `donation.html`, `raid.html`

**Pro tip:** Right-click a source > **Copy** to duplicate it across scenes.

## Step 4: Add Full-Screen Scenes

### Starting Soon
1. Switch to the **Starting Soon** scene
2. Click `+` > **Browser**
3. Local file: `scenes/starting-soon.html`
4. Width: `1920`, Height: `1080`
5. URL params for countdown: Add `?minutes=10` to set a 10-minute timer

### BRB
1. Switch to **BRB** scene
2. Add Browser Source: `scenes/brb.html` at 1920x1080

### Ending
1. Switch to **Ending** scene
2. Add Browser Source: `scenes/ending.html` at 1920x1080

## Step 5: Configure Transitions

1. Go to **Settings > Scene Transitions** (or the transition dropdown between Scenes and Sources)
2. Set transition to **Fade** at 300ms for smooth scene switching
3. You can also set per-scene transitions by right-clicking a scene

## Browser Source Tips

- **Check "Shutdown source when not visible"** for scenes you switch away from (saves CPU)
- **Check "Refresh browser when scene becomes active"** for the Starting Soon countdown
- **Uncheck "Custom CSS"** in the browser source settings (the overlay has its own styles)
- If overlays look wrong, make sure OBS canvas is set to 1920x1080 (Settings > Video)

## Streamlabs Desktop Setup

The process is nearly identical in Streamlabs:
1. Click `+` next to Sources
2. Choose **Browser Source**
3. Use the **Browse** button to select the HTML file
4. Set the dimensions as listed above

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Overlay has a white/black background | Make sure you're using the HTML files as **local files**, not URLs |
| Fonts look wrong | Your computer needs internet access for Google Fonts to load |
| Alerts don't trigger | You need to uncomment and configure the WebSocket code in each alert file |
| Webcam frame doesn't align | Resize both the webcam and frame sources to match. Right-click > Transform > Edit Transform for precise control |
| Countdown doesn't start from right time | Add `?minutes=10` (or your desired time) to the URL field |
| Colors look different | Make sure your OBS color format is set to NV12 or I444 in Settings > Advanced |
