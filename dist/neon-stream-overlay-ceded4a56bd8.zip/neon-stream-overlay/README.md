# Neon Stream Overlay - Cyberpunk Theme

A complete, ready-to-use stream overlay package with a cyberpunk/neon aesthetic. Works with OBS Studio, Streamlabs, and any software that supports Browser Sources.

## What's Included

| File | Description | OBS Size |
|------|-------------|----------|
| `webcam-frame.html` | Glowing neon border for your webcam | 420x236 |
| `chat-box.html` | Styled chat container with neon theme | 400x600 |
| `alerts/follow.html` | New follower alert animation | 500x200 |
| `alerts/sub.html` | Subscription alert with tier display | 500x200 |
| `alerts/donation.html` | Donation alert with money rain effect | 500x200 |
| `alerts/raid.html` | Raid alert with dramatic entrance | 500x250 |
| `panels/game-info.html` | Current game + stream title | 300x80 |
| `panels/recent-events.html` | Latest followers, subs, donors | 300x200 |
| `panels/goals.html` | Sub/donation goal progress bar | 300x60 |
| `scenes/gaming.html` | Full gaming scene layout | 1920x1080 |
| `scenes/starting-soon.html` | Pre-stream countdown screen | 1920x1080 |
| `scenes/brb.html` | "Be Right Back" screen | 1920x1080 |
| `scenes/ending.html` | End-of-stream with social links | 1920x1080 |
| `style.css` | Shared styles with CSS variables | - |
| `config.json` | Your customization settings | - |

## Quick Start

1. **Edit `config.json`** - Set your streamer name, game, and social links
2. **Open `scenes/gaming.html`** in your browser to preview
3. **Add to OBS** as Browser Sources (see SETUP.md for step-by-step)
4. **Customize colors** by editing CSS variables in `style.css`

## Customization

### Change Colors
Open `style.css` and edit the CSS variables at the top:

```css
:root {
  --neon-primary: #00f0ff;    /* Main glow color (cyan) */
  --neon-secondary: #ff00e5;  /* Accent color (pink) */
  --neon-tertiary: #7b00ff;   /* Third accent (purple) */
}
```

### Change Fonts
The overlay uses Google Fonts (Orbitron + Rajdhani). To change:
1. Pick fonts from [Google Fonts](https://fonts.google.com)
2. Replace the `@import` URL in `style.css`
3. Update `--font-display` and `--font-body` variables

### Change Webcam Size
Edit `style.css`:
```css
:root {
  --webcam-width: 420px;
  --webcam-height: 236px;  /* Keep 16:9 ratio */
}
```

## Alert Integration

Alerts can connect to your streaming platform via WebSocket. Each alert file has commented-out integration code for:

- **StreamElements** - Paste your overlay token
- **Streamlabs** - Paste your socket token  
- **Custom WebSocket** - Connect to any server

See the `<script>` section in each alert file for setup instructions.

## Testing Alerts

Open any alert HTML file in your browser:
- It plays the animation automatically on load
- **Click anywhere** to replay with random test data
- Sub alerts cycle through Tier 1, 2, and 3 on each click
- Donation alerts show different amounts on each click

## Browser Compatibility

- Chrome/Chromium (OBS uses this internally)
- Firefox
- Edge
- Safari

## License

MIT License - Use freely in your streams, modify as you wish.
