#!/usr/bin/env python3
"""
Stream Schedule Generator — Neon Bazaar Creator Kit
====================================================
Reads a schedule JSON file and generates a dark-neon-themed HTML
schedule graphic. Perfect for sharing on social media, Discord,
or embedding in your Twitch panels.

Usage:
    python3 schedule_generator.py --input schedule.json
    python3 schedule_generator.py --input schedule.json --output my-schedule.html
    python3 schedule_generator.py --input schedule.json --accent "#ff2d9b"
"""

from __future__ import annotations

import argparse
import json
import sys
import textwrap
from pathlib import Path
from typing import Any


# ============================================================================
# CONSTANTS
# ============================================================================

DAYS_ORDER = [
    "monday", "tuesday", "wednesday", "thursday",
    "friday", "saturday", "sunday",
]

DAY_ABBREV = {
    "monday": "MON", "tuesday": "TUE", "wednesday": "WED",
    "thursday": "THU", "friday": "FRI", "saturday": "SAT",
    "sunday": "SUN",
}

# Stream type → emoji/icon hint (used in the HTML output)
TYPE_ICONS = {
    "ranked": "&#9876;",      # Crossed swords
    "chill": "&#9749;",       # Coffee
    "collab": "&#9733;",      # Star
    "tournament": "&#9889;",  # Lightning
    "creative": "&#9998;",    # Pencil
    "variety": "&#127918;",   # Game controller
    "irl": "&#127908;",       # Microphone
    "special": "&#127881;",   # Party popper
}

DEFAULT_ACCENT = "#00f0ff"
DEFAULT_SECONDARY = "#ff00e5"
DEFAULT_BG = "#0a0a0f"


# ============================================================================
# HTML GENERATION
# ============================================================================

def generate_schedule_html(
    data: dict[str, Any],
    accent: str = DEFAULT_ACCENT,
    secondary: str = DEFAULT_SECONDARY,
    bg: str = DEFAULT_BG,
) -> str:
    """Generate a complete HTML schedule graphic from schedule data."""

    streamer = data.get("streamer_name", "Streamer")
    timezone = data.get("timezone", "EST")
    week = data.get("week", {})
    special = data.get("special_events", [])

    # Build day rows
    day_rows = ""
    for day in DAYS_ORDER:
        info = week.get(day, {"live": False})
        abbr = DAY_ABBREV[day]

        if info.get("live"):
            time_str = info.get("time", "TBD")
            end_str = info.get("end_time", "")
            game = info.get("game", "TBD")
            stream_type = info.get("type", "variety")
            icon = TYPE_ICONS.get(stream_type, "&#127918;")
            time_range = f"{time_str} - {end_str}" if end_str else time_str

            day_rows += textwrap.dedent(f"""\
                <div class="day-row live">
                  <div class="day-label">{abbr}</div>
                  <div class="day-time">{time_range}</div>
                  <div class="day-game"><span class="type-icon">{icon}</span> {game}</div>
                  <div class="day-badge live-badge">LIVE</div>
                </div>
            """)
        else:
            day_rows += textwrap.dedent(f"""\
                <div class="day-row off">
                  <div class="day-label">{abbr}</div>
                  <div class="day-time">—</div>
                  <div class="day-game">Off Day</div>
                  <div class="day-badge off-badge">OFF</div>
                </div>
            """)

    # Build special events
    events_html = ""
    if special:
        events_list = ""
        for evt in special:
            evt_day = DAY_ABBREV.get(evt.get("day", ""), "???")
            events_list += (
                f'<div class="event-item">'
                f'<span class="event-name">{evt.get("name", "Event")}</span>'
                f'<span class="event-detail">{evt_day} @ {evt.get("time", "TBD")} — {evt.get("description", "")}</span>'
                f'</div>\n'
            )
        events_html = f"""\
        <div class="special-events">
          <div class="section-title">Special Events</div>
          {events_list}
        </div>
        """

    html = textwrap.dedent(f"""\
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>{streamer} — Stream Schedule</title>
      <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
      <style>
        *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

        body {{
          background: {bg};
          color: #ffffff;
          font-family: 'Rajdhani', sans-serif;
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 100vh;
          padding: 20px;
        }}

        .schedule-card {{
          background: linear-gradient(145deg, rgba(15, 15, 25, 0.95), rgba(5, 5, 15, 0.98));
          border: 2px solid {accent};
          border-radius: 16px;
          padding: 40px;
          width: 100%;
          max-width: 700px;
          box-shadow:
            0 0 30px color-mix(in srgb, {accent} 25%, transparent),
            inset 0 0 60px rgba(0, 0, 0, 0.5);
          position: relative;
          overflow: hidden;
        }}

        .schedule-card::before {{
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 3px;
          background: linear-gradient(90deg, transparent, {accent}, {secondary}, {accent}, transparent);
        }}

        .header {{
          text-align: center;
          margin-bottom: 32px;
        }}

        .header h1 {{
          font-family: 'Orbitron', sans-serif;
          font-size: 28px;
          font-weight: 900;
          text-transform: uppercase;
          letter-spacing: 4px;
          color: {accent};
          text-shadow: 0 0 20px color-mix(in srgb, {accent} 50%, transparent);
        }}

        .header .subtitle {{
          font-size: 16px;
          color: #8899aa;
          margin-top: 4px;
          letter-spacing: 2px;
          text-transform: uppercase;
        }}

        .timezone {{
          display: inline-block;
          background: color-mix(in srgb, {accent} 15%, transparent);
          color: {accent};
          font-family: 'Orbitron', sans-serif;
          font-size: 11px;
          padding: 4px 12px;
          border-radius: 20px;
          margin-top: 12px;
          letter-spacing: 2px;
        }}

        .day-row {{
          display: grid;
          grid-template-columns: 70px 150px 1fr 70px;
          align-items: center;
          padding: 14px 16px;
          margin-bottom: 6px;
          border-radius: 8px;
          transition: all 0.2s;
        }}

        .day-row.live {{
          background: linear-gradient(90deg, color-mix(in srgb, {accent} 10%, transparent), transparent);
          border-left: 3px solid {accent};
        }}

        .day-row.off {{
          opacity: 0.4;
          border-left: 3px solid transparent;
        }}

        .day-label {{
          font-family: 'Orbitron', sans-serif;
          font-weight: 700;
          font-size: 14px;
          letter-spacing: 2px;
        }}

        .day-row.live .day-label {{ color: {accent}; }}
        .day-row.off .day-label {{ color: #555; }}

        .day-time {{
          font-size: 15px;
          color: #cccccc;
          font-weight: 500;
        }}

        .day-game {{
          font-size: 16px;
          font-weight: 600;
          color: #ffffff;
        }}

        .type-icon {{
          margin-right: 4px;
          font-size: 14px;
        }}

        .day-badge {{
          font-family: 'Orbitron', sans-serif;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 2px;
          text-align: center;
          padding: 3px 8px;
          border-radius: 4px;
        }}

        .live-badge {{
          background: color-mix(in srgb, {accent} 20%, transparent);
          color: {accent};
          border: 1px solid color-mix(in srgb, {accent} 40%, transparent);
        }}

        .off-badge {{
          color: #444;
        }}

        .special-events {{
          margin-top: 28px;
          padding-top: 20px;
          border-top: 1px solid color-mix(in srgb, {secondary} 30%, transparent);
        }}

        .section-title {{
          font-family: 'Orbitron', sans-serif;
          font-size: 13px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 3px;
          color: {secondary};
          margin-bottom: 14px;
          text-shadow: 0 0 10px color-mix(in srgb, {secondary} 40%, transparent);
        }}

        .event-item {{
          display: flex;
          flex-direction: column;
          padding: 10px 14px;
          margin-bottom: 6px;
          background: color-mix(in srgb, {secondary} 8%, transparent);
          border-left: 3px solid {secondary};
          border-radius: 6px;
        }}

        .event-name {{
          font-weight: 700;
          font-size: 15px;
          color: {secondary};
        }}

        .event-detail {{
          font-size: 13px;
          color: #8899aa;
          margin-top: 2px;
        }}

        .footer {{
          text-align: center;
          margin-top: 24px;
          font-size: 12px;
          color: #445;
          letter-spacing: 1px;
        }}
      </style>
    </head>
    <body>
      <div class="schedule-card">
        <div class="header">
          <h1>{streamer}</h1>
          <div class="subtitle">Stream Schedule</div>
          <div class="timezone">All times {timezone}</div>
        </div>

        <div class="schedule-grid">
          {day_rows}
        </div>

        {events_html}

        <div class="footer">Schedule subject to change &bull; Follow for go-live notifications</div>
      </div>
    </body>
    </html>
    """)

    return html


# ============================================================================
# CLI
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate a neon-themed stream schedule graphic from a JSON file",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            examples:
              %(prog)s --input schedule.json
              %(prog)s --input schedule.json --output my-schedule.html
              %(prog)s --input schedule.json --accent "#ff2d9b"
        """),
    )
    parser.add_argument(
        "--input", "-i",
        type=str,
        required=True,
        help="Path to schedule JSON file",
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default="schedule.html",
        help="Output HTML file path (default: schedule.html)",
    )
    parser.add_argument(
        "--accent",
        type=str,
        default=DEFAULT_ACCENT,
        help=f"Primary accent color hex (default: {DEFAULT_ACCENT})",
    )
    parser.add_argument(
        "--secondary",
        type=str,
        default=DEFAULT_SECONDARY,
        help=f"Secondary accent color hex (default: {DEFAULT_SECONDARY})",
    )
    parser.add_argument(
        "--bg",
        type=str,
        default=DEFAULT_BG,
        help=f"Background color hex (default: {DEFAULT_BG})",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Terminal colors
    cyan = "\033[96m"
    green = "\033[92m"
    red = "\033[91m"
    dim = "\033[2m"
    reset = "\033[0m"

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"  {red}Error:{reset} File not found: {input_path}")
        sys.exit(1)

    try:
        data = json.loads(input_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"  {red}Error:{reset} Invalid JSON: {exc}")
        sys.exit(1)

    print(f"\n  {cyan}Generating schedule...{reset}")
    print(f"  {dim}Input:  {input_path}{reset}")

    html = generate_schedule_html(
        data,
        accent=args.accent,
        secondary=args.secondary,
        bg=args.bg,
    )

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")

    streamer = data.get("streamer_name", "Streamer")
    live_days = sum(
        1 for d in DAYS_ORDER
        if data.get("week", {}).get(d, {}).get("live", False)
    )
    events = len(data.get("special_events", []))

    print(f"  {green}Done!{reset} Schedule generated for {streamer}")
    print(f"  {dim}Live days: {live_days}/7 | Special events: {events}{reset}")
    print(f"  {dim}Output: {output_path.resolve()}{reset}\n")


if __name__ == "__main__":
    main()
