# Stream Schedule Maker

**Create beautiful stream schedule graphics your viewers will actually check.** Includes a Python schedule generator, interactive schedule builder, and a ready-to-share HTML template. Dark neon theme that matches the Creator Kit aesthetic.

## What's Inside

| File | What It Does |
|------|-------------|
| `src/schedule_generator.py` | Python script — reads a JSON schedule and generates an HTML schedule graphic |
| `src/schedule_template.json` | Schedule data template (days, times, games, special events) |
| `examples/sample_schedule.json` | Example filled-out weekly schedule |
| `demo/index.html` | Interactive schedule builder — click to set streams, pick games, export |
| `preview/index.html` | Static preview of a sample generated schedule |
| `templates/weekly.html` | Standalone HTML schedule template — dark neon, shareable |

## Quick Start

### Generate a Schedule Graphic
```bash
# Generate from the sample schedule
python3 src/schedule_generator.py --input examples/sample_schedule.json

# Generate with a custom output path
python3 src/schedule_generator.py --input examples/sample_schedule.json --output my-schedule.html

# Generate with custom accent color
python3 src/schedule_generator.py --input examples/sample_schedule.json --accent "#ff2d9b"
```

### Use the Interactive Builder
Open `demo/index.html` in your browser. Click time slots, type in game names, toggle days on/off, then hit **Export** to download your schedule as HTML.

### Use the Template Directly
Open `templates/weekly.html` in any text editor. Replace the placeholder text with your actual stream times and games, then open in a browser and screenshot it.

## Schedule JSON Format

```json
{
  "streamer_name": "YourName",
  "timezone": "EST",
  "week": {
    "monday": { "live": true, "time": "7:00 PM", "end_time": "10:00 PM", "game": "Valorant", "type": "ranked" },
    "tuesday": { "live": false },
    "wednesday": { "live": true, "time": "8:00 PM", "end_time": "11:00 PM", "game": "Just Chatting", "type": "chill" }
  },
  "special_events": [
    { "name": "Sub Sunday", "day": "sunday", "time": "2:00 PM", "description": "Viewer games + giveaways" }
  ]
}
```

## Customization

### Change Colors
The generator and all HTML files use CSS variables:

```css
:root {
  --neon-primary: #00f0ff;     /* Main accent (cyan) */
  --neon-secondary: #ff00e5;   /* Secondary accent (pink) */
  --bg-dark: #0a0a0f;          /* Background */
}
```

### Change Fonts
All templates use Google Fonts (Orbitron + Rajdhani). Swap the `@import` URL to use different fonts.

## File Structure

```
stream-schedule-maker/
├── README.md
├── LICENSE
├── src/
│   ├── schedule_generator.py    # Schedule graphic generator
│   └── schedule_template.json   # Blank schedule template
├── examples/
│   └── sample_schedule.json     # Filled-out example schedule
├── demo/
│   └── index.html               # Interactive schedule builder
├── preview/
│   └── index.html               # Static schedule preview
└── templates/
    └── weekly.html              # Standalone shareable schedule
```

## Requirements

- Any modern browser to view HTML files
- Python 3.10+ for the generator script
- No pip packages needed — stdlib only

## License

MIT License — use it for your stream, remix it, share it. Go wild.
