#!/usr/bin/env python3
"""
Emote Generator — Neon Bazaar Creator Kit
==========================================
Generates customizable SVG emotes from base templates.
Supports custom colors, sizes, and batch generation.

Usage:
    python3 emote_generator.py --emotion happy
    python3 emote_generator.py --emotion angry --color "#FF2D9B" --bg "#0D0D1A"
    python3 emote_generator.py --all --output-dir ./my-emotes
    python3 emote_generator.py --list
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import textwrap
from pathlib import Path
from typing import Optional

# ============================================================================
# EMOTE DEFINITIONS
# ============================================================================
# Each emote is defined as an SVG template string with color placeholders.
# {face_color}  — Main face/head fill
# {accent_color} — Eyes, mouth, special features
# {bg_color}     — Background circle/shape (optional)
# {highlight}    — Highlights, sparkles, blush
# ============================================================================

# Platform size presets (width x height in pixels)
PLATFORM_SIZES: dict[str, list[tuple[int, int]]] = {
    "twitch": [(28, 28), (56, 56), (112, 112)],
    "discord": [(32, 32), (64, 64), (128, 128)],  # Nitro: up to 128
    "youtube": [(24, 24), (48, 48)],
    "all": [(28, 28), (32, 32), (48, 48), (56, 56), (64, 64), (112, 112), (128, 128)],
}

# Default neon color scheme
DEFAULT_FACE = "#FFD93D"       # Warm yellow
DEFAULT_ACCENT = "#FF2D9B"     # Neon pink
DEFAULT_BG = "#1A1A2E"         # Dark background
DEFAULT_HIGHLIGHT = "#00D4FF"  # Electric blue

EMOTIONS: list[str] = [
    "happy", "sad", "angry", "shocked", "laughing",
    "love", "thinking", "cool", "sleepy", "hype",
]


def get_emote_svg(
    emotion: str,
    face_color: str = DEFAULT_FACE,
    accent_color: str = DEFAULT_ACCENT,
    bg_color: str = DEFAULT_BG,
    highlight_color: str = DEFAULT_HIGHLIGHT,
    size: int = 128,
) -> str:
    """
    Generate an SVG string for the given emotion.

    Instead of loading external template files, this function contains the
    complete SVG definitions inline so the script works standalone.
    If a matching template file exists in src/templates/, it will use that
    instead (with color replacement).

    Args:
        emotion: One of the EMOTIONS list
        face_color: Hex color for the face
        accent_color: Hex color for accent features (eyes, mouth details)
        bg_color: Hex color for the background
        highlight_color: Hex color for highlights and sparkles
        size: Output size in pixels

    Returns:
        Complete SVG string
    """
    # Try to load from template file first
    template_path = Path(__file__).parent / "templates" / f"{emotion}.svg"
    if template_path.exists():
        svg_content = template_path.read_text(encoding="utf-8")
        # Replace color placeholders if the template uses them
        svg_content = svg_content.replace("{face_color}", face_color)
        svg_content = svg_content.replace("{accent_color}", accent_color)
        svg_content = svg_content.replace("{bg_color}", bg_color)
        svg_content = svg_content.replace("{highlight}", highlight_color)
        # Update viewBox size if needed
        svg_content = re.sub(
            r'width="\d+"', f'width="{size}"', svg_content
        )
        svg_content = re.sub(
            r'height="\d+"', f'height="{size}"', svg_content
        )
        return svg_content

    # Fallback: generate from inline definitions
    return _generate_inline_svg(
        emotion, face_color, accent_color, bg_color, highlight_color, size
    )


def _generate_inline_svg(
    emotion: str,
    face: str,
    accent: str,
    bg: str,
    highlight: str,
    size: int,
) -> str:
    """Generate SVG from inline definitions (fallback if template files missing)."""

    # Common SVG header
    header = (
        f'<svg xmlns="http://www.w3.org/2000/svg" '
        f'width="{size}" height="{size}" viewBox="0 0 128 128">\n'
    )
    footer = "</svg>"

    # Background circle + face base (shared by all emotes)
    base = (
        f'  <circle cx="64" cy="64" r="60" fill="{bg}" />\n'
        f'  <circle cx="64" cy="64" r="52" fill="{face}" />\n'
    )

    # Emotion-specific features
    features = _get_features(emotion, face, accent, bg, highlight)

    return header + base + features + footer


def _get_features(
    emotion: str, face: str, accent: str, bg: str, highlight: str
) -> str:
    """Return SVG elements for the facial features of each emotion."""

    match emotion:
        case "happy":
            return (
                # Squinted happy eyes
                f'  <path d="M38 52 Q44 44 50 52" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                f'  <path d="M78 52 Q84 44 90 52" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                # Big smile
                f'  <path d="M40 72 Q64 96 88 72" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                # Blush
                f'  <circle cx="34" cy="68" r="8" fill="{accent}" opacity="0.3"/>\n'
                f'  <circle cx="94" cy="68" r="8" fill="{accent}" opacity="0.3"/>\n'
            )
        case "sad":
            return (
                # Sad eyes with tears
                f'  <circle cx="44" cy="50" r="6" fill="{accent}"/>\n'
                f'  <circle cx="84" cy="50" r="6" fill="{accent}"/>\n'
                # Eyebrows (worried)
                f'  <path d="M34 40 Q44 36 54 42" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                f'  <path d="M74 42 Q84 36 94 40" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Frown
                f'  <path d="M44 82 Q64 70 84 82" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                # Tear
                f'  <ellipse cx="46" cy="62" rx="3" ry="5" fill="{highlight}" opacity="0.7"/>\n'
            )
        case "angry":
            return (
                # Angry eyes
                f'  <circle cx="44" cy="52" r="7" fill="{accent}"/>\n'
                f'  <circle cx="84" cy="52" r="7" fill="{accent}"/>\n'
                # Angry eyebrows (V-shaped)
                f'  <path d="M30 38 L54 46" stroke="{accent}" stroke-width="4" stroke-linecap="round"/>\n'
                f'  <path d="M98 38 L74 46" stroke="{accent}" stroke-width="4" stroke-linecap="round"/>\n'
                # Gritted teeth
                f'  <rect x="42" y="74" width="44" height="14" rx="3" fill="white"/>\n'
                f'  <line x1="53" y1="74" x2="53" y2="88" stroke="{accent}" stroke-width="1.5"/>\n'
                f'  <line x1="64" y1="74" x2="64" y2="88" stroke="{accent}" stroke-width="1.5"/>\n'
                f'  <line x1="75" y1="74" x2="75" y2="88" stroke="{accent}" stroke-width="1.5"/>\n'
                # Red cheek marks
                f'  <path d="M22 58 L30 54 L22 50" stroke="{accent}" stroke-width="2" fill="none"/>\n'
                f'  <path d="M106 58 L98 54 L106 50" stroke="{accent}" stroke-width="2" fill="none"/>\n'
            )
        case "shocked":
            return (
                # Wide eyes
                f'  <circle cx="44" cy="50" r="12" fill="white"/>\n'
                f'  <circle cx="44" cy="50" r="6" fill="{accent}"/>\n'
                f'  <circle cx="84" cy="50" r="12" fill="white"/>\n'
                f'  <circle cx="84" cy="50" r="6" fill="{accent}"/>\n'
                # Raised eyebrows
                f'  <path d="M32 32 Q44 24 56 32" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                f'  <path d="M72 32 Q84 24 96 32" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Open mouth (O shape)
                f'  <ellipse cx="64" cy="82" rx="14" ry="16" fill="{accent}"/>\n'
                f'  <ellipse cx="64" cy="82" rx="10" ry="12" fill="{bg}"/>\n'
            )
        case "laughing":
            return (
                # Closed laughing eyes (XD style)
                f'  <path d="M34 48 L44 54 L54 48" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                f'  <path d="M34 54 L44 48 L54 54" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                f'  <path d="M74 48 L84 54 L94 48" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                f'  <path d="M74 54 L84 48 L94 54" stroke="{accent}" stroke-width="4" fill="none" stroke-linecap="round"/>\n'
                # Wide open mouth
                f'  <path d="M38 72 Q64 100 90 72 Z" fill="{accent}"/>\n'
                f'  <path d="M44 72 Q64 64 84 72" fill="{face}"/>\n'
                # Tears of joy
                f'  <ellipse cx="28" cy="60" rx="4" ry="6" fill="{highlight}" opacity="0.6"/>\n'
                f'  <ellipse cx="100" cy="60" rx="4" ry="6" fill="{highlight}" opacity="0.6"/>\n'
            )
        case "love":
            return (
                # Heart eyes
                f'  <path d="M36 46 C36 40 44 38 44 46 C44 38 52 40 52 46 C52 54 44 58 44 58 C44 58 36 54 36 46Z" fill="{accent}"/>\n'
                f'  <path d="M76 46 C76 40 84 38 84 46 C84 38 92 40 92 46 C92 54 84 58 84 58 C84 58 76 54 76 46Z" fill="{accent}"/>\n'
                # Blushing cheeks
                f'  <circle cx="34" cy="68" r="9" fill="{accent}" opacity="0.35"/>\n'
                f'  <circle cx="94" cy="68" r="9" fill="{accent}" opacity="0.35"/>\n'
                # Happy mouth
                f'  <path d="M46 76 Q64 90 82 76" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Floating hearts
                f'  <path d="M16 28 C16 24 20 22 20 28 C20 22 24 24 24 28 C24 32 20 34 20 34 C20 34 16 32 16 28Z" fill="{accent}" opacity="0.5"/>\n'
                f'  <path d="M100 22 C100 18 104 16 104 22 C104 16 108 18 108 22 C108 26 104 28 104 28 C104 28 100 26 100 22Z" fill="{highlight}" opacity="0.5"/>\n'
            )
        case "thinking":
            return (
                # One raised eyebrow
                f'  <path d="M34 40 L54 36" stroke="{accent}" stroke-width="3" stroke-linecap="round"/>\n'
                f'  <path d="M74 44 Q84 40 94 44" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Eyes (one squinting)
                f'  <circle cx="44" cy="52" r="5" fill="{accent}"/>\n'
                f'  <path d="M78 52 Q84 48 90 52" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Slight frown / thinking mouth
                f'  <path d="M52 78 Q60 82 72 78" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Hand on chin
                f'  <circle cx="76" cy="86" r="8" fill="{face}" stroke="{accent}" stroke-width="2"/>\n'
                # Thought bubble
                f'  <circle cx="102" cy="28" r="8" fill="{highlight}" opacity="0.3"/>\n'
                f'  <circle cx="96" cy="38" r="4" fill="{highlight}" opacity="0.2"/>\n'
                f'  <circle cx="92" cy="44" r="2" fill="{highlight}" opacity="0.15"/>\n'
            )
        case "cool":
            return (
                # Sunglasses
                f'  <rect x="28" y="44" width="28" height="18" rx="4" fill="{bg}"/>\n'
                f'  <rect x="72" y="44" width="28" height="18" rx="4" fill="{bg}"/>\n'
                f'  <line x1="56" y1="52" x2="72" y2="52" stroke="{bg}" stroke-width="3"/>\n'
                # Shine on glasses
                f'  <rect x="32" y="47" width="8" height="3" rx="1" fill="{highlight}" opacity="0.5"/>\n'
                f'  <rect x="76" y="47" width="8" height="3" rx="1" fill="{highlight}" opacity="0.5"/>\n'
                # Confident smirk
                f'  <path d="M48 76 Q64 84 80 74" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Sparkle
                f'  <path d="M104 32 L106 28 L108 32 L112 34 L108 36 L106 40 L104 36 L100 34Z" fill="{highlight}"/>\n'
            )
        case "sleepy":
            return (
                # Droopy closed eyes
                f'  <path d="M34 54 Q44 58 54 54" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                f'  <path d="M74 54 Q84 58 94 54" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
                # Slight open mouth (yawning)
                f'  <ellipse cx="64" cy="80" rx="10" ry="8" fill="{accent}"/>\n'
                f'  <ellipse cx="64" cy="80" rx="7" ry="5" fill="{bg}"/>\n'
                # ZZZ bubble
                f'  <text x="94" y="28" font-family="sans-serif" font-size="16" font-weight="bold" fill="{highlight}">Z</text>\n'
                f'  <text x="102" y="20" font-family="sans-serif" font-size="12" font-weight="bold" fill="{highlight}" opacity="0.7">Z</text>\n'
                f'  <text x="108" y="14" font-family="sans-serif" font-size="9" font-weight="bold" fill="{highlight}" opacity="0.4">Z</text>\n'
                # Blush
                f'  <circle cx="34" cy="66" r="7" fill="{accent}" opacity="0.2"/>\n'
                f'  <circle cx="94" cy="66" r="7" fill="{accent}" opacity="0.2"/>\n'
            )
        case "hype":
            return (
                # Star eyes
                f'  <polygon points="44,42 47,50 56,50 49,55 51,64 44,58 37,64 39,55 32,50 41,50" fill="{highlight}"/>\n'
                f'  <polygon points="84,42 87,50 96,50 89,55 91,64 84,58 77,64 79,55 72,50 81,50" fill="{highlight}"/>\n'
                # Wide open excited mouth
                f'  <path d="M38 72 Q64 104 90 72 Z" fill="{accent}"/>\n'
                f'  <path d="M46 72 Q64 66 82 72" fill="{face}"/>\n'
                # Sparkles around
                f'  <path d="M18 36 L20 32 L22 36 L26 38 L22 40 L20 44 L18 40 L14 38Z" fill="{highlight}" opacity="0.7"/>\n'
                f'  <path d="M102 24 L104 20 L106 24 L110 26 L106 28 L104 32 L102 28 L98 26Z" fill="{accent}" opacity="0.7"/>\n'
                f'  <path d="M108 62 L109 60 L110 62 L112 63 L110 64 L109 66 L108 64 L106 63Z" fill="{highlight}" opacity="0.5"/>\n'
                # Action lines
                f'  <line x1="10" y1="50" x2="18" y2="52" stroke="{highlight}" stroke-width="2" opacity="0.4"/>\n'
                f'  <line x1="110" y1="50" x2="118" y2="48" stroke="{highlight}" stroke-width="2" opacity="0.4"/>\n'
            )
        case _:
            # Unknown emotion — render a simple smiley
            return (
                f'  <circle cx="44" cy="50" r="5" fill="{accent}"/>\n'
                f'  <circle cx="84" cy="50" r="5" fill="{accent}"/>\n'
                f'  <path d="M44 76 Q64 88 84 76" stroke="{accent}" stroke-width="3" fill="none" stroke-linecap="round"/>\n'
            )


def save_emote(
    svg_content: str,
    output_path: Path,
) -> None:
    """Save an SVG emote to a file."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(svg_content, encoding="utf-8")


def generate_platform_sizes(
    emotion: str,
    platform: str,
    output_dir: Path,
    face_color: str = DEFAULT_FACE,
    accent_color: str = DEFAULT_ACCENT,
    bg_color: str = DEFAULT_BG,
    highlight_color: str = DEFAULT_HIGHLIGHT,
) -> list[Path]:
    """Generate emote at all sizes required by a platform."""
    sizes = PLATFORM_SIZES.get(platform, PLATFORM_SIZES["all"])
    generated: list[Path] = []

    for width, height in sizes:
        svg = get_emote_svg(
            emotion, face_color, accent_color, bg_color, highlight_color,
            size=max(width, height),
        )
        filename = f"{emotion}_{width}x{height}.svg"
        path = output_dir / filename
        save_emote(svg, path)
        generated.append(path)

    return generated


# ============================================================================
# CLI
# ============================================================================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate SVG emotes for Twitch, Discord, and YouTube",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            examples:
              %(prog)s --emotion happy
              %(prog)s --emotion angry --color "#FF2D9B"
              %(prog)s --all --output-dir ./my-emotes
              %(prog)s --emotion laughing --platform twitch
              %(prog)s --list
        """),
    )
    parser.add_argument(
        "--emotion", "-e",
        type=str,
        help="Emotion to generate (happy, sad, angry, etc.)",
    )
    parser.add_argument(
        "--all", "-a",
        action="store_true",
        help="Generate all emotions",
    )
    parser.add_argument(
        "--color",
        type=str,
        default=DEFAULT_FACE,
        help=f"Face color (hex, default: {DEFAULT_FACE})",
    )
    parser.add_argument(
        "--accent",
        type=str,
        default=DEFAULT_ACCENT,
        help=f"Accent color (hex, default: {DEFAULT_ACCENT})",
    )
    parser.add_argument(
        "--bg",
        type=str,
        default=DEFAULT_BG,
        help=f"Background color (hex, default: {DEFAULT_BG})",
    )
    parser.add_argument(
        "--highlight",
        type=str,
        default=DEFAULT_HIGHLIGHT,
        help=f"Highlight color (hex, default: {DEFAULT_HIGHLIGHT})",
    )
    parser.add_argument(
        "--size", "-s",
        type=int,
        default=128,
        help="Output size in pixels (default: 128)",
    )
    parser.add_argument(
        "--platform",
        type=str,
        choices=["twitch", "discord", "youtube", "all"],
        help="Generate at platform-specific sizes",
    )
    parser.add_argument(
        "--output-dir", "-o",
        type=str,
        default="./emotes",
        help="Output directory (default: ./emotes)",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List available emotions",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # Terminal colors for pretty output
    pink = "\033[95m"
    cyan = "\033[96m"
    green = "\033[92m"
    dim = "\033[2m"
    reset = "\033[0m"

    if args.list:
        print(f"\n  {cyan}Available emotions:{reset}")
        for em in EMOTIONS:
            print(f"    {pink}>{reset} {em}")
        print()
        return

    if not args.emotion and not args.all:
        parser.error("--emotion or --all is required (use --list to see options)")

    output_dir = Path(args.output_dir)
    emotions_to_gen = EMOTIONS if args.all else [args.emotion.lower()]

    for emotion in emotions_to_gen:
        if emotion not in EMOTIONS:
            print(f"  {pink}Warning:{reset} Unknown emotion '{emotion}', skipping")
            continue

        if args.platform:
            paths = generate_platform_sizes(
                emotion, args.platform, output_dir,
                args.color, args.accent, args.bg, args.highlight,
            )
            for p in paths:
                print(f"  {green}Created:{reset} {p}")
        else:
            svg = get_emote_svg(
                emotion, args.color, args.accent, args.bg, args.highlight,
                size=args.size,
            )
            path = output_dir / f"{emotion}.svg"
            save_emote(svg, path)
            print(f"  {green}Created:{reset} {path}")

    total = len(emotions_to_gen)
    print(f"\n  {cyan}Done!{reset} Generated {total} emote{'s' if total != 1 else ''}.")
    print(f"  {dim}Files saved to: {output_dir.resolve()}{reset}\n")


if __name__ == "__main__":
    main()
