# Emote Design Tips — How to Make Emotes That Stand Out

> A practical guide to creating emotes your community actually wants to use.
> Written for creators who are new to emote design.

---

## The Golden Rule of Emotes

**If you can't tell what the emote is at 28×28 pixels, redesign it.**

Emotes live in chat. Chat is tiny. Your beautiful detailed artwork becomes a blurry blob at chat size. Design for the SMALLEST display size, then add detail for larger versions.

---

## 1. Start With Emotion, Not Art

The best emotes express a **feeling** or **reaction** instantly:

| Emotion | Visual Shorthand | When Viewers Use It |
|---------|-----------------|-------------------|
| Hype | Wide eyes, raised arms, speed lines | Something epic happens |
| Sadness | Single tear, droopy eyes, rain | Streamer loses, sad moment |
| Anger | Red face, steam, furrowed brows | Frustration, rage quit |
| Love | Heart eyes, floating hearts | Wholesome moment |
| Shock | Wide open mouth, spiral eyes | Plot twist, unexpected event |
| Thinking | Hand on chin, raised eyebrow | Debating, sus moment |
| Cool | Sunglasses, smirk | Flex, smooth play |
| Laughing | Tears of joy, open mouth | Comedy gold |

**Pro tip:** Before designing, ask your community "what emotes do you wish we had?" — they'll tell you exactly what reactions are missing from your chat.

---

## 2. Color Theory for Emotes

### Colors That Pop in Chat
Chat backgrounds are usually **dark gray** (#18181B on Twitch, #313338 on Discord). Design for contrast against dark backgrounds.

**Best emote colors:**
- 🔥 **Neon pink (#FF2D9B)** — High visibility, eye-catching
- ⚡ **Electric blue (#00D4FF)** — Cool, stands out on dark BG
- 🟢 **Acid green (#39FF14)** — Impossible to miss
- 🟡 **Bright yellow (#FFE500)** — Classic attention-grabber
- 🟠 **Hot orange (#FF6B2B)** — Warm, energetic

**Avoid:**
- Dark blues, dark greens, dark reds — they disappear on dark backgrounds
- Pastels — too subtle at small sizes
- Gray tones — blend into the chat background

### The 2-3 Color Rule
Great emotes use **2-3 colors max** (plus outline). More colors = more visual noise = harder to read at small sizes.

```
Good:  Yellow face + Pink blush + Black outline = 3 colors, clear
Bad:   Rainbow gradient + 6 accessories + patterns = visual chaos
```

---

## 3. Outlines Are Everything

A solid outline is what makes an emote readable at any size. Here's what works:

| Source Size | Outline Width | Notes |
|------------|--------------|-------|
| 128×128 | 3-4 px | Standard for Discord/7TV |
| 112×112 | 2-3 px | Twitch source size |
| 512×512 | 8-12 px | If designing at high-res first |

### Outline Tips
- **Black outlines** work on any background
- **Dark colored outlines** (dark blue, dark purple) feel softer than pure black
- **Double outlines** (dark inner + light outer glow) add depth and visibility
- **Consistent width** — don't mix thick and thin outlines in one emote

---

## 4. Expressions That Read at Any Size

### Eyes Are the #1 Priority
Viewers read emotes by their **eyes** first. Make eyes the largest, most detailed feature.

- **Big, simple eyes** > realistic small eyes
- **Solid color fills** > detailed irises at small sizes
- **Position matters** — eyes slightly above center feels more natural
- **Highlight dots** (small white circles) bring eyes to life

### Mouths Convey the Emotion
- **Open mouth** = excited, shocked, laughing (use for hype moments)
- **Closed smile** = content, knowing, smug
- **Wavy/squiggle** = uncomfortable, nervous, cringe
- **Wide frown** = dramatically sad
- **Fangs/teeth showing** = evil, mischievous, gamer rage

### Accessories Add Personality (Use Sparingly)
- Sunglasses → cool/flex emote
- Crown/halo → royalty/sub badge
- Headphones → gaming/music
- Fire/sparkles → hype effects
- Sweat drops → nervous/relief

**Rule:** One accessory per emote. Two max. More than that and it's cluttered.

---

## 5. Creating a Cohesive Emote Set

If you're making multiple emotes (which you should), keep them consistent:

### Maintain These Across All Emotes:
- **Same outline width** and color
- **Same face shape/style** (round, square, blob — pick one)
- **Same eye style** (dot eyes, anime eyes, circle eyes — stay consistent)
- **Same color palette** (reuse your brand colors)
- **Same canvas padding** (don't have one emote filling the canvas and another floating in the middle)

### Recommended Set Composition
Start with these **5 essential emotes** before adding niche ones:

1. **Happy/Hype** — Your most-used emote (general positivity)
2. **Sad/Cry** — For F-in-chat moments
3. **Love/Heart** — Wholesome reactions
4. **Laughing/LOL** — Comedy response
5. **Your signature** — A unique emote that represents YOUR brand

Then expand with:
6. Thinking/Sus
7. Angry/Rage
8. Cool/Flex
9. Shocked/Pog
10. Sleepy/Comfy

---

## 6. Common Mistakes (and Fixes)

### Mistake: Too Much Detail
```
Problem:  Detailed shading, tiny patterns, realistic features
Result:   Blurry mess at 28px
Fix:      Simplify. Flat colors, bold shapes, minimal shading.
```

### Mistake: Text in Emotes
```
Problem:  "LOL", "GG", "RIP" written inside the emote
Result:   Unreadable below 56px
Fix:      Use visual symbols instead (tears of joy > "LOL" text)
Exception: 1-2 BIG letters that fill the whole canvas can work
```

### Mistake: No Outline
```
Problem:  Emote has no border/outline
Result:   Edges blend into chat background
Fix:      Add a 2-4px dark outline around the entire shape
```

### Mistake: Square/Rectangular Design
```
Problem:  Design fills a square with no transparency
Result:   Looks like a stamp, not an emote
Fix:      Use organic shapes with transparent background
```

### Mistake: Designing at Chat Size
```
Problem:  Creating art at 28×28 from the start
Result:   No room for refinement, everything is pixelated
Fix:      Design at 112×128, then verify it scales down well
```

---

## 7. Tools for Creating Emotes

### Free Tools
| Tool | Platform | Best For |
|------|----------|----------|
| **This toolkit!** | CLI/Any | Quick SVG emote base templates |
| Inkscape | Desktop | Vector editing (SVG native) |
| GIMP | Desktop | Pixel art emotes, PNG editing |
| Photopea | Web | Photoshop alternative (free) |
| Pixlr | Web | Quick edits and exports |
| LibreSprite | Desktop | Pixel art animation |

### Paid Tools (If You Want to Level Up)
| Tool | Price | Best For |
|------|-------|----------|
| Clip Studio Paint | $50 one-time | Drawing + animation |
| Procreate | $13 one-time (iPad) | Drawing on tablet |
| Adobe Illustrator | $21/mo | Pro vector work |
| Aseprite | $20 one-time | Pixel art emotes |

---

## 8. Workflow: From Idea to Emote

```
Step 1: Pick the emotion/reaction you want to express
   ↓
Step 2: Sketch 3-5 rough thumbnails at SMALL size (think postage stamp)
   ↓
Step 3: Pick the clearest one — if you can tell what it is from the thumbnail, it'll work
   ↓
Step 4: Create the vector/pixel art at 112-128px
   ↓
Step 5: Add bold outline (2-4px)
   ↓
Step 6: Export at all required platform sizes (use emote_generator.py for SVG bases)
   ↓
Step 7: Test on actual platforms — send in a test Discord server or use BetterTTV preview
   ↓
Step 8: Get feedback from 2-3 people — "what emotion does this convey?"
   ↓
Step 9: Iterate based on feedback, re-export, upload!
```

---

## 9. Making Money From Emotes

Once you've got the skills, emote design is a real side hustle:

- **Fiverr/Commission**: $5-50 per custom emote (beginners: $5-15, experienced: $25-50)
- **Emote packs**: Sell sets of 5-10 themed emotes on your store
- **Sub emotes**: Create exclusive emotes as subscriber perks
- **Community contests**: Let your viewers vote on new emote designs for engagement

---

## Quick Reference: The Emote Checklist

Before uploading any emote, verify:

- [ ] Readable at 28×28 pixels (the tiny chat size)
- [ ] Has a solid outline (2-4px at source size)  
- [ ] Transparent background (no white/solid BG)
- [ ] 2-3 colors maximum (plus outline color)
- [ ] Eyes are the most prominent feature
- [ ] Emotion is instantly recognizable
- [ ] Exported at all required platform sizes
- [ ] File size is under the platform's limit
- [ ] Filename uses no spaces (letters, numbers, underscores only)
- [ ] Not a copy of copyrighted characters
