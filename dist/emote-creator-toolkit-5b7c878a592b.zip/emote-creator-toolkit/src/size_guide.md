# Emote Size Guide — Platform Requirements

> Quick reference for emote dimensions across Twitch, Discord, YouTube, and more.
> Last updated: 2025

---

## Twitch Emotes

Twitch requires **three sizes** for each emote. Upload the largest and Twitch auto-scales, but results are better if you provide all three.

| Size Name | Dimensions | Use Case |
|-----------|-----------|----------|
| 1x | 28×28 px | Chat (small screens) |
| 2x | 56×56 px | Chat (default) |
| 3x (4x) | 112×112 px | Emote picker, previews |

**Format:** PNG with transparent background  
**Max file size:** 25 KB per size  
**Naming:** No spaces, letters/numbers only  
**Slots:** Affiliates get 1-5 emote slots. Partners get 5-60+.

### Twitch Tips
- Design at 112×112, then check it still reads at 28×28
- Use thick outlines (2-3px at full size) so edges don't disappear at small sizes
- Avoid thin details — they turn to mush below 56px
- Test on both dark AND light chat backgrounds (some users use light mode)

---

## Discord Emotes

| Type | Dimensions | Max Size | Notes |
|------|-----------|----------|-------|
| Server Emoji | 128×128 px | 256 KB | Static PNG or GIF |
| Server Sticker | 320×320 px | 512 KB | PNG, APNG, or Lottie JSON |
| Animated Emoji | 128×128 px | 256 KB | GIF or APNG, max 60 frames |

**Slots by boost level:**
- Level 0: 50 emoji + 5 stickers
- Level 1: 100 emoji + 15 stickers  
- Level 2: 150 emoji + 30 stickers
- Level 3: 250 emoji + 60 stickers

### Discord Tips
- Discord renders emotes at ~22px in chat — keep it simple
- Transparent backgrounds look best in both dark and light themes
- Animated emotes autoplay, so make the animation loop seamlessly
- Name your emotes descriptively (`:pepehype:` not `:emote47:`)

---

## YouTube Membership Emotes

| Size Name | Dimensions | Notes |
|-----------|-----------|-------|
| Primary | 48×48 px | Used in live chat |
| Required sizes | 24×24, 48×48 px | Both required for upload |
| Recommended | 24, 32, 40, 48 px | All four for best quality |

**Format:** PNG, transparent background  
**Max file size:** 1 MB  
**Slots:** Based on membership tier count  

### YouTube Tips
- YouTube live chat is tiny — design for readability at 24px
- Bright colors and high contrast work best against the dark chat BG
- Avoid text in emotes — it's unreadable at these sizes
- YouTube compresses aggressively, so start with crisp source files

---

## 7TV / BetterTTV / FrankerFaceZ

Third-party Twitch extensions have their own specs:

| Platform | Dimensions | Max Size | Animated? |
|----------|-----------|----------|-----------|
| 7TV | 128×128 (up to 4x) | 2.5 MB | Yes (WEBP/AVIF) |
| BTTV | 112×112 | 2.5 MB | Yes (GIF) |
| FFZ | 128×128 | 1 MB | No (static only) |

### Third-Party Tips
- 7TV supports the widest emotes (up to 4:1 ratio) — great for wide reactions
- BTTV animated emotes can have up to 120 frames
- FFZ is static-only but has the best rendering quality
- All three platforms support transparent backgrounds

---

## Universal Design Rules

### Do's ✓
- **Design at the LARGEST size** first, then scale down to check readability
- **Use bold outlines** (2-4px at source size) for visibility at small scales
- **High contrast colors** — neon brights on transparent BG work great
- **Simple shapes** — the emote should be recognizable as a tiny icon
- **Test at actual size** — zoom out your editor to see how it really looks
- **Keep the focal point centered** — platforms may crop edges

### Don'ts ✗
- **Don't use thin lines** — they vanish at 28px
- **Don't add text** — unreadable at chat size (except maybe 1-2 huge letters)
- **Don't use gradients with subtle differences** — they band at low resolution
- **Don't leave whitespace padding** — use the full canvas
- **Don't forget transparency** — white backgrounds look amateur
- **Don't copy copyrighted characters** — platforms WILL take them down

---

## Quick Conversion with emote_generator.py

Use the included `emote_generator.py` script to auto-generate platform-ready sizes:

```bash
# Generate Twitch sizes (28, 56, 112px)
python3 emote_generator.py --emotion happy --platform twitch --output ./my-emotes/

# Generate Discord sizes (128px)
python3 emote_generator.py --emotion hype --platform discord --output ./my-emotes/

# Generate all platform sizes at once
python3 emote_generator.py --emotion cool --platform all --output ./my-emotes/

# Batch generate all emotions for Twitch
python3 emote_generator.py --all --platform twitch --output ./my-emotes/
```

The script outputs SVG files at the correct dimensions. To convert to PNG (required by most platforms), use any SVG-to-PNG tool:
- **Online:** svgtopng.com, cloudconvert.com
- **Desktop:** Inkscape (free), Adobe Illustrator
- **CLI:** `inkscape --export-type=png --export-width=112 emote.svg`

---

## File Size Optimization

If your exported PNGs are too large:

1. **Reduce colors** — Use indexed PNG (PNG-8) for simple emotes
2. **Remove metadata** — Strip EXIF data with tools like `pngcrush` or `optipng`
3. **Simplify shapes** — Fewer anchor points = smaller SVG = smaller PNG
4. **Resize canvas** — Don't upload 512px when the platform only needs 128px
5. **Use TinyPNG** — Web tool that compresses PNG without visible quality loss
