# Emote Creator Toolkit

**Design custom emotes for Twitch, Discord, and YouTube.** Includes 10 SVG base templates, a Python emote generator, platform size guides, and pro design tips. Go from "I need emotes" to "I MADE emotes" in minutes.

## What's Inside

| File | What It Does |
|------|-------------|
| `src/emote_generator.py` | Python SVG emote generator — creates emotes from templates |
| `src/templates/` | 10 SVG emote base templates (happy, sad, angry, etc.) |
| `src/size_guide.md` | Exact size requirements for Twitch, Discord, and YouTube |
| `src/design_tips.md` | Pro tips for making emotes that stand out |
| `preview/gallery.html` | Visual gallery of all included templates |

## Quick Start

### Generate Emotes
```bash
# Generate a happy emote with default colors
python3 src/emote_generator.py --emotion happy

# Generate with custom neon colors
python3 src/emote_generator.py --emotion angry --color "#FF2D9B" --bg "#0D0D1A"

# Generate ALL emotions at once
python3 src/emote_generator.py --all

# Generate for a specific platform size
python3 src/emote_generator.py --emotion laughing --platform twitch

# List available emotions
python3 src/emote_generator.py --list
```

### Browse Templates
Open `preview/gallery.html` in any browser to see all 10 emote bases side by side.

### Customize
1. Open any SVG from `src/templates/` in a text editor or vector tool (Inkscape is free)
2. Change colors by editing the `fill` attributes
3. Add your own details — hair, accessories, text
4. Export at the sizes listed in `src/size_guide.md`

## Included Emote Templates

| # | Emotion | File | Description |
|---|---------|------|-------------|
| 1 | Happy | `happy.svg` | Big smile, squinted eyes — your go-to PogChamp |
| 2 | Sad | `sad.svg` | Teary eyes, downturned mouth |
| 3 | Angry | `angry.svg` | Furrowed brows, gritted teeth |
| 4 | Shocked | `shocked.svg` | Wide eyes, open mouth — for big moments |
| 5 | Laughing | `laughing.svg` | Tears of joy, huge grin |
| 6 | Love | `love.svg` | Heart eyes, blushing cheeks |
| 7 | Thinking | `thinking.svg` | Hand on chin, raised eyebrow |
| 8 | Cool | `cool.svg` | Sunglasses, confident smirk |
| 9 | Sleepy | `sleepy.svg` | Droopy eyes, ZZZ bubble |
| 10 | Hype | `hype.svg` | Star eyes, open mouth, sparkles |

## Customization Ideas

- **Change skin tone** — Edit the face `fill` color
- **Add hair** — Draw paths on top of the head circle
- **Add accessories** — Headphones, hats, glasses are easy SVG additions
- **Channel branding** — Use your channel colors for the accent elements
- **Text emotes** — Replace the face with text like "GG", "EZ", or your channel name

## Requirements

- Any modern browser to view SVGs and the gallery
- Python 3.10+ for the generator script
- No pip packages needed — stdlib only
- Optional: Inkscape, Figma, or any SVG editor for advanced customization

## File Structure

```
emote-creator-toolkit/
├── README.md
├── LICENSE
├── src/
│   ├── emote_generator.py      # SVG emote generator script
│   ├── size_guide.md           # Platform size requirements
│   ├── design_tips.md          # How to make great emotes
│   └── templates/              # 10 SVG emote bases
│       ├── happy.svg
│       ├── sad.svg
│       ├── angry.svg
│       ├── shocked.svg
│       ├── laughing.svg
│       ├── love.svg
│       ├── thinking.svg
│       ├── cool.svg
│       ├── sleepy.svg
│       └── hype.svg
└── preview/
    └── gallery.html            # Visual template gallery
```

## License

MIT License — use these emotes on your channel, remix them, sell your custom versions. Go wild.
